# Code Description ############################################################
# Date: 09_08_2021
# Written by: Matthew Baister, Ewan McTaggart

# This script reads in data and manipulates it into a useable format
# for plotting against our model solution. 



# Useful outputs from running this file are:
#
# 1) Lothian$DailyPositive = the number of positive COVID-19 tests recorded 
#                            across the whole NHS Lothian health board on the 
#                            dates Lothian$Date. This includes care home
#                            residents
# 
# 2) Weekly_Deaths_Lothian = the number of weekly deaths recorded in the NHS Lothian health 
#                            board (by National Records Scotland) with COVID-19 
#                            mentioned on the death certificate. This includes 
#                            care home residents
#
# 3a) Lothian_CH_7_day_positive_data = the 7 day average number of positive COVID-19 
#                                      tests recorded ONLY for CH residents across the whole 
#                                      NHS Lothian health board on the dates Lothian_CH_7_day_positive_data$Date. This includes those in care homes
#
# 3b) Lothian_CH_death_data = the weekly number of care home reisdents who died from
#                             COVID-19 in the NHS Lothian health board 
#                             board with COVID-19.  
#
# 4) weekly_csr_cases = Weekly cases across whole of Lothian. Weekly sums of data 1)
#
# 5) = an estimate of the weekly number of CH residents in NHS Lothian that tested positive
#                                   for COVID-19. Weekly sums of data 3a)

# Important notes: 
#
#  - The first date for our simulations is 06/03/2020. This is the first day 
#    with >1 positive tests in the NHS Lothian health board
#
#  - The last date for our simulations is 15/06/2020. This is the day after
#    last date in CH case data. It is also last day in adjusted seroprevalence study
#    for Scotland which was used to calculate overall reporting rate
#    ("Enhanced surveillance of COVID-19 in Scotland: population-based seroprevalence 
#    surveillance for SARS-CoV-2 during the first wave of the epidemic") - see word doc. 
#    It is also when first wave starts to die down (in positive tests) and plateaus 
#    at very low levels in the Lothian PHS case data.
#
#  - To plot the data against the model output, the length of simTime
#    in scipt 2_SEIRD must be the same length as Date.sim (102). Date.sim is a vector of
#    dates going from 06/03/2020 and 15/06/2020.




# 1) Read in Daily NHS board data from Public Health Scotland --------------
Daily_Cases_NHS_BOARD_PHS<- read.table("Daily_Cases_NHS_BOARD_PHS.txt", 
                                       sep = "\t", header=TRUE)
Daily_Cases_NHS_BOARD_PHS$Date<-as.Date(as.character(Daily_Cases_NHS_BOARD_PHS$Date), format = "%Y%m%d")  #make first column dates for plotting
#str(Daily_Cases_NHS_BOARD_PHS)    #make sure it's ok

# # Choose the healthboard
# levels(Daily_Cases_NHS_BOARD_PHS$HB)
# NHS_code_names<-c("NHS Ayrshire and Arran",     # these were taken from PHS website and are in order of HB codes i.e. levels(Daily_Cases_NHS_BOARD_PHS$HB)
#                   "NHS Borders",
#                   "NHS Dumfries and Galloway",
#                   "NHS Forth Valley",
#                   "NHS Grampian",
#                   "NHS Highland",
#                   "NHS Lothian",
#                   "NHS Orkney",
#                   "NHS Shetland",
#                   "NHS Western Isles",
#                   "NHS Fife",
#                   "NHS Tayside",
#                   "NHS Greater Glasgow and Clyde",
#                   "NHS Lanarkshire")
#levels(Daily_Cases_NHS_BOARD_PHS$HB)<-NHS_code_names
#Lothian<-Daily_Cases_NHS_BOARD_PHS[which(Daily_Cases_NHS_BOARD_PHS$HB=="NHS Lothian"),]    
Lothian<-Daily_Cases_NHS_BOARD_PHS[which(Daily_Cases_NHS_BOARD_PHS$HB=="S08000024"),]

# Start date is first date with more than 1 new case. Roughly when cases start increasing/stop being flat.
start_time<-min((1:nrow(Lothian))[Lothian$DailyPositive>1],na.rm=T) # 06/03/2020 if 1st day with >1 case. OR corresponds to 09/03/2020 if day of more than 2 cases, 04/03/2020 if day of 1st case. 
Lothian<-Lothian[Lothian$Date>=Lothian$Date[start_time] & Lothian$Date<=as.Date("2020-06-15") ,]   # keep info between this day and before 15/06/2020 - day after last date in CH case data + last day in adjusted seroprevalence study for Scotland which was used to calculate overall reporting rate - see word doc. Also is when first wave starts to die down and levels off at very low levels in the PHS case data.

# keep only columns 1 and 3, corresponding to dates and number of positive tests
Lothian<-Lothian[,c(1,3)]

#Date.sim <- seq.Date(as.Date("2020-03-06"), length.out=length(Lothian$Date), by=1)
Date.sim <- seq.Date(as.Date(Lothian$Date[1]), length.out=length(Lothian$Date), by=1)
# Remember length(simTime) must = length(Date.sim)



# 2) Read in Weekly death data for Lothian ------------------

Weekly_Deaths_Lothian<- read.table("Weekly_Deaths_Lothian_NRS.txt",
                                   sep = "\t", header=TRUE)
Weekly_Deaths_Lothian$Date<-as.Date(as.character(Weekly_Deaths_Lothian$Date), format = "%d-%b-%y")  #make first column dates for plotting
# str(Weekly_Deaths_Lothian)    #make sure it's ok

# keep data between "2020-03-06" and "2020-06-15" i.e. first and late date we use in PHS data
Weekly_Deaths_Lothian<-Weekly_Deaths_Lothian[Weekly_Deaths_Lothian$Date>=as.Date("2020-03-06") & Weekly_Deaths_Lothian$Date<=as.Date("2020-06-15") ,]



# 3) Lothian CH data from Prof Guthrie, Dr Burton et al -----------

# The data from the paper Evolution and effects of COVID-19 outbreaks in care homes: a population analysis in 189 care homes in one geographical region of the UK

# NOTE THAT IN THE CSV EXCEL SHEETS WE HAVE RANDOMISED THE DATA. THE REAL DATA IS AVAILABLE ON REQUEST FROM
# PROF BRUCE GUTHRIE, SEE https://doi.org/10.1016/S2666-7568(20)30012-X 

# 3a) 7-day average of COVID-19 positive tests in CHs -----------

Lothian_CH_7_day_positive_data <- read.csv("Care_Home_7DayAverageCases_NHS_Lothian.csv")
colnames(Lothian_CH_7_day_positive_data)<-c("Week commencing", "Date", "7 day rolling average positive tests")

Lothian_CH_7_day_positive_data$Date<-as.Date(substr(Lothian_CH_7_day_positive_data$Date, start=1, stop=10), format = "%d-%b-%y")     # keep the first 10 characters of the date variable. i.e. remove the "utc" part. Also ensure variable is in date form for plotting

# keep data with dates between "2020-03-06" and "2020-06-15" i.e. first and late dates for study (see above PHS case data comments) 
Lothian_CH_7_day_positive_data<-Lothian_CH_7_day_positive_data[Lothian_CH_7_day_positive_data$Date>=as.Date("2020-03-06") & Lothian_CH_7_day_positive_data$Date<=as.Date("2020-06-15") ,]
# Note the Lothian CH data starts on "2020-03-09"

# remove first few rows with an NA value for 7-day average of positive cases in CHs

firstNonNA <- min(which(!is.na(Lothian_CH_7_day_positive_data$`7 day rolling average positive tests`)))    # index of first value of Lothian_CH_7_day_positive_data$`7 day rolling average positive tests` that isn't NA
Lothian_CH_7_day_positive_data <- Lothian_CH_7_day_positive_data[firstNonNA:nrow(Lothian_CH_7_day_positive_data),]




# 3b) Weekly CH COVID-19 death data ---------------

# NOTE THAT IN THE CSV EXCEL SHEETS WE HAVE RANDOMISED THE DATA. THE REAL DATA IS AVAILABLE ON REQUEST FROM
# PROF BRUCE GUTHRIE, SEE https://doi.org/10.1016/S2666-7568(20)30012-X 

Lothian_CH_death_data <- read.csv("Care_Home_WeeklyDeaths_NHS_Lothian.csv") # read in excel sheet 3 which is the data with weekly deaths
colnames(Lothian_CH_death_data)<-c("Week commencing","All deaths, average of previous 5 years","All deaths 2020","COVID-19 deaths 2020","Non COVID-19 deaths 2020") 

Lothian_CH_death_data <- Lothian_CH_death_data[1:(nrow(Lothian_CH_death_data)-1),] # remove the last row as this is just the totals

Lothian_CH_death_data$`Week commencing`<-c(substr(Lothian_CH_death_data$`Week commencing`[1:9], start=10, stop = 15)       # remove the characters "Week x :"
                                           ,substr(Lothian_CH_death_data$`Week commencing`[10:length(Lothian_CH_death_data$`Week commencing`)], start=11, stop=16)) # and "Week xx :"
Lothian_CH_death_data$`Week commencing`<-as.Date(as.character(paste(Lothian_CH_death_data$`Week commencing`, "-2020", sep = ""))     # add 2020 to the end of each date,
                                                 ,format = "%d-%b-%y")    # and ensure they can be plotted as dates (by using as.Date)

# keep data between "2020-03-06" and "2020-06-15" i.e. first and late dates for study (see above PHS case data comments) 
Lothian_CH_death_data<-Lothian_CH_death_data[Lothian_CH_death_data$`Week commencing`>=as.Date("2020-03-06") & Lothian_CH_death_data$`Week commencing`<=as.Date("2020-06-15") ,]

# Notes: 
# - the Lothian_CH_death_data has a column for "COVID-19 related deaths 2020". This is what we will use for plotting and least squares. Judging from paper this includes deaths 
#       of residents that occur in care homes and in hospitals
# - the data is also weekly totals not cumulative up to week x
# - it is not clear if the data for each week are deaths that happen that week



# 4) Weekly case data for whole of Lothain (CSR) ------------

# The dates of weekly cases are the same as those for weekly deaths
# for each date the weekly cases is those that occur that day and those
# from the previous six days

# These weekly totals are derived from the Lothain daily case data in 1)

weekly_csr_cases <- diff(c(0, (cumsum(Lothian$DailyPositive)[Lothian$Date %in% Weekly_Deaths_Lothian$Date])))
weekly_csr_case_dates <- Lothian$Date[Lothian$Date %in% Weekly_Deaths_Lothian$Date]

# 5) Weekly case data for CH residents in NHS Lothian ---------

# The dates of weekly cases are the same as those for weekly deaths
# for each date the weekly cases is those that occur that day and those
# from the previous six days

# These weekly totals are derived from the Lothain CH daily case data in 3a).
# Note however that this was the 7 day average of cases so this weekly total
# is just the total of the 7 day average counts across a week

weekly_ch_cases <- diff(c(0, (cumsum(Lothian_CH_7_day_positive_data$`7 day rolling average positive tests`)[Lothian_CH_7_day_positive_data$Date %in% Lothian_CH_death_data$`Week commencing`])))
weekly_ch_case_dates <- Lothian_CH_7_day_positive_data$Date[Lothian_CH_7_day_positive_data$Date %in% Lothian_CH_death_data$`Week commencing`]

