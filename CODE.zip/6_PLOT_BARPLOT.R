# Code Description ############################################################
# Date: 09_08_2021
# Written by: Matthew Baister, Ewan McTaggart


# This script is to plot the barplots (tornado plots) showing sensitivity of model to its parameters.
# A parameter is shifted up or down by a fixed value from the 4 home fitted base case

# 1) Preamble - Source scripts with SEIRD functions, load in barplots from different fits parameters
# 2) Listed here are the parameters we test the sensitivity of
# 3) Load in the barplot data and manipulate into a ggplot friendly form (dataframes)
# 4) Plot the increase/decrease by "shift" bars on same plot. Single value of homes seeded. 



# 1) Preamble ----------------------------------------------------------

# if (!"ggplot2" %in% installed.packages())
#   install.packages("ggplot2")
library(ggplot2)

# if (!"parallel" %in% installed.packages())
#   install.packages("parallel")
library(parallel)               # Library with parallelised verisions of lapply etc. For calculating model output for different sets of parameters.

# if (!"patchwork" %in% installed.packages())
#   install.packages("patchwork")
library(patchwork)

# if (!"plyr" %in% installed.packages())
#   install.packages("plyr")
library(plyr)


# import the SEIRD functions and baseline parameters from the R scripts:
# source('2_SEIRD.R')


# 2) Parameters we plot ---------------------

baseline_names<-c("beta_rr_high"
                  ,"beta_rr_low"
                  ,"beta_rr_rate"
                  ,"beta_rr_end"
                  ,"beta_c_high"
                  ,"beta_c_low"
                  ,"beta_c_rate"
                  ,"beta_c_end"
                  ,"delta"
                  ,"epsilon"
                  ,"gamma"
                  ,"initial_infected_R_total"
                  ,"latency"
                  ,"tau")


# 3) Load in barplot data (lists) and manipulate into dataframes ------------

# Load in barplot data

load("final_deaths_change_storage_C_seeding_varied.RData")

final_deaths_change_storage_C_seeding_varied$increase_by_shift


# Choose which parameters to plot

params_plotted <- baseline_names

# Now manipulate the data into ggplot friendly format

{
  
  # 4% (4 homes) seeded in E CH sensitivity barplot data
  
  vec1 <- final_deaths_change_storage_C_seeding_varied$increase_by_shift$C[4,]
  vec1 <- vec1[params_plotted]
  vec2 <- final_deaths_change_storage_C_seeding_varied$decrease_by_shift$C[4,]
  vec2 <- vec2[params_plotted]
  
  data4E<-rbind(data.frame(CHs_seeded = "4 homes", Parameter=names(vec1), Final_deaths = as.numeric(vec1), Direction = "Increase", row.names=NULL)
                ,data.frame(CHs_seeded = "4 homes", Parameter=names(vec2), Final_deaths = as.numeric(vec2), Direction = "Decrease", row.names=NULL)
  )
  
  
  CH_data <- rbind(data4E)
  
  

  # Also store all S data in a dataframe
  
  # 4% (4 homes) seeded in E S sensitivity barplot data
  
  vec1 <- final_deaths_change_storage_C_seeding_varied$increase_by_shift$S[4,]
  vec1 <- vec1[params_plotted]
  vec2 <- final_deaths_change_storage_C_seeding_varied$decrease_by_shift$S[4,]
  vec2 <- vec2[params_plotted]
  
  data4E<-rbind(data.frame(CHs_seeded = "4 homes", Parameter=names(vec1), Final_deaths = as.numeric(vec1), Direction = "Increase", row.names=NULL)
                ,data.frame(CHs_seeded = "4 homes", Parameter=names(vec2), Final_deaths = as.numeric(vec2), Direction = "Decrease", row.names=NULL)
  )
  
  
  S_data <- rbind(data4E)
  
  
  
  # Finally store all R data in a dataframe
  
  # 4% (4 homes) seeded in E R sensitivity barplot data
  
  vec1 <- final_deaths_change_storage_C_seeding_varied$increase_by_shift$R[4,]
  vec1 <- vec1[params_plotted]
  vec2 <- final_deaths_change_storage_C_seeding_varied$decrease_by_shift$R[4,]
  vec2 <- vec2[params_plotted]
  
  data4E<-rbind(data.frame(CHs_seeded = "4 homes", Parameter=names(vec1), Final_deaths = as.numeric(vec1), Direction = "Increase", row.names=NULL)
                ,data.frame(CHs_seeded = "4 homes", Parameter=names(vec2), Final_deaths = as.numeric(vec2), Direction = "Decrease", row.names=NULL)
  )
  
  
    R_data <- rbind(data4E)
  
}






# 4) Plot increase + decrease by shift bars on same plot for a fixed percentage of homes seeded --------- 


# Choose the fixed percentage  of homes 
fixed_homes <- "4 homes"       

# if fixing the y limits on the barplots...

y_limits <- range(rbind(CH_data[CH_data$CHs_seeded == fixed_homes, "Final_deaths"]
                        ,S_data[S_data$CHs_seeded == fixed_homes, "Final_deaths"]
                        ,R_data[R_data$CHs_seeded == fixed_homes, "Final_deaths"])
)


# Function to make the plots


increase_decrease_barplot <- function(chosen_title, chosen_subtitle, data){
  
  
  # set the x labels for each barplot
  # by changing names of levels of data$Parameter
  
    
    levels(data$Parameter) <-  c("omega[end]^C"
                                 ,"omega[high]^C"
                                 ,"omega[low]^C"
                                 ,"omega[rate]^C"
                                 ,"omega[end]^G"
                                 ,"omega[high]^G"
                                 ,"omega[low]^G"
                                 ,"omega[rate]^G"
                                 ,"delta"
                                 ,"epsilon"
                                 ,"omega[high]^gamma"
                                 ,"E[G](0)"
                                 ,"lambda"
                                 ,"tau")
  
    y_breaks <- c(-15,-10,-5,0)
    
  the_plot <- ggplot(mapping = aes(x = Parameter, y = Final_deaths, fill = factor(Direction))) +
    labs(x = "\nParameter"
         ,y = "% Change in deaths\n"
         #,tag = ""
    ) + ggtitle(chosen_subtitle) +
    theme_bw() +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,axis.text.x = element_text(size = 10, angle = 0, vjust = 0.5)
          ,legend.position = c(0.5,1.13)#"right" #c(0.5,1.13)
          ,legend.direction = "vertical"#"horizontal"
          ,legend.background = element_rect(linetype = 1, size = 0.5, colour = 1)
          ,plot.margin= unit(c(45.5,5.5,5.5,5.5),"pt")
          ,legend.text.align = 0
          #,legend.title = element_blank()
          ) +
    geom_col(data = data[data$CHs_seeded == fixed_homes, ], position = "identity", color = "black", alpha  = 0.5) +
    scale_fill_discrete(name = "Sensitivity shift"
                        ,guide = guide_legend()
                        ,labels = c("increase","decrease")
                        ) +

    guides(fill = guide_legend(label.position = "left", title.position = "top")) +
  scale_x_discrete(limits = rev(levels(data$Parameter)), labels = rev(parse(text=levels(data$Parameter)))) +
  theme(axis.text.x = element_text(angle = 0)
        ,axis.text.y = element_text(size = 13)
        ,axis.title.x=element_text(vjust=-1.8, hjust = 0.5)
        ,axis.title.y=element_text(vjust=3.0, hjust = 0.6)
        ) +
  #coord_flip(ylim = y_limits)

    scale_y_continuous(breaks = unique(c(y_breaks,-y_breaks)), labels = unique(c(y_breaks,-y_breaks)))+#, limits = c(-max(data$Final_deaths),max(data$Final_deaths))) +
  coord_flip(ylim = c(-max(data$Final_deaths),max(data$Final_deaths)))
  
  
  return(the_plot)
}


# if converting to absolute change instead of % run this
# load("baseline_deaths")
# CH_data$Final_deaths <- CH_data$Final_deaths*baseline_deaths$C/100
# S_data$Final_deaths <- S_data$Final_deaths*baseline_deaths$S/100
# R_data$Final_deaths <- R_data$Final_deaths*baseline_deaths$R/100

# make the plot


# # C, S and R side by side
# C_plot <- increase_decrease_barplot(paste(fixed_homes, " seeded", sep = ""),"Care home residents", CH_data) + theme(legend.position = "none") # + annotate("text", x = 3, y = 20, label = "Care home residents") 
# S_plot <- increase_decrease_barplot("","Workers", S_data) + theme(axis.title.y = element_blank(),  
#                                                                   axis.text.y = element_blank()
#                                                                   ) 
# R_plot <- increase_decrease_barplot("","General population", R_data) + theme(axis.title.y = element_blank(),  
#                                                                            axis.text.y = element_blank()) + theme(legend.position = "none") 
# 
# 
# single_fit_CSR_barplot <- C_plot + S_plot + R_plot #& theme(legend.position = "top") #+ plot_layout(guides = "collect") 
# single_fit_CSR_barplot <- single_fit_CSR_barplot #+ plot_layout(guides = "collect")
# ggsave(plot = single_fit_CSR_barplot, filename = "test_single_fit_CSR_barplot_legend_top.png"
#        ,units = "mm", width=410, height = 180)



# C, S and R vertically
C_plot <- increase_decrease_barplot(paste(fixed_homes, " seeded", sep = ""),"Care home residents", CH_data) + theme(legend.position = "none") # + annotate("text", x = 3, y = 20, label = "Care home residents") 
S_plot <- increase_decrease_barplot("","Workers", S_data) #+ theme(axis.title.y = element_blank(),  
#       axis.text.y = element_blank()
#      ) 
R_plot <- increase_decrease_barplot("","General population", R_data) #+ theme(axis.title.y = element_blank(),  

single_fit_CSR_barplot <- C_plot + labs(tag="(a)") + theme(plot.margin = unit(c(1,1,1,1), "mm")) + 
  S_plot + labs(tag="(b)") + theme(plot.margin = unit(c(1,1,1,1), "mm")) +
  R_plot + labs(tag="(c)") + theme(plot.margin = unit(c(1,1,1,1), "mm")) +
    plot_layout(nrow = 3, guides = "collect") 
ggsave(plot = single_fit_CSR_barplot, filename = "single_fit_CSR_barplot_all_vertical.png"
       ,units = "mm", width=200, height = 430)



