# Code Description ############################################################
# Date: 09_08_2021
# Written by: Matthew Baister, Ewan McTaggart


# This script is to compare fitted models and their parameters (for each homes seeded)


# 1) Preamble - Source scripts with SEIRD functions, load in packages
# 2) Load in the fitted model data and manipulate into a ggplot friendly form (dataframes)
# 3) Make the plots 


# 1) Preamble ----------------------------------------------------------

# clear environment
rm(list = ls())

# if (!"plotly" %in% installed.packages())
#   install.packages("plotly")
#library(plotly)                  # A plotting library for making heatmaps. Plots are interactive. 

# if (!"ggplot2" %in% installed.packages())
#   install.packages("ggplot2")
library(ggplot2)

# if (!"patchwork" %in% installed.packages())
#   install.packages("patchwork")
library(patchwork)

# if (!"tidyr" %in% installed.packages())
#   install.packages("tidyr")
library(tidyr)


# Read in case and death data to calculate least squares against:

source('READ_DATA.R')

# Color generating function found here:
# http://stackoverflow.com/questions/8197559/emulate-ggplot2-default-color-palette
gg_color_hue <- function(n) {
  hues = seq(15, 375, length=n+1)
  hcl(h=hues, l=65, c=100)[1:n]
}


# Also we need to choose how many of the top scenarios (parameter sets) to
# visualise, for each value of home seeded. This impacts the plots labelled
# 3c)-3g) in the script outline.

# FIX NUMBER OF TOP SCENARIOS ---------- 

number_top_scenarios <- 10




# 2) Load in the fitted model data ----------------

# using each script 4 + 5 we generated these lists of data we need
load("seeded_1home_E_best_fit.RData")
load("seeded_2home_E_best_fit.RData")
load("seeded_3home_E_best_fit.RData")
load("seeded_4home_E_best_fit.RData")
load("seeded_5home_E_best_fit.RData")
load("seeded_6home_E_best_fit.RData")
load("seeded_7home_E_best_fit.RData")
load("seeded_8home_E_best_fit.RData")
load("seeded_9home_E_best_fit.RData")
load("seeded_10home_E_best_fit.RData")


# 3) Make plots -------------------

# 3a) Fitted time series ----------------

# Manipulate into a ggplot friendly format

CSR_cases <- rbind(data.frame(What = "Data", Date = weekly_csr_case_dates, y_data = weekly_csr_cases, Type = "p", row.names=NULL)
                   ,data.frame(What = "Model: 1 home seeded", Date = weekly_csr_case_dates, y_data = seeded_1home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 2 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_2home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 3 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_3home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 4 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_4home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 5 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_5home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 6 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_6home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 7 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_7home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 8 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_8home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 9 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_9home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
                   ,data.frame(What = "Model: 10 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_10home_E_best_fit$Model_weekly_total_cases, Type = "l", row.names=NULL)
)
CSR_cases$What <- as.factor(CSR_cases$What)
CSR_cases$What <- factor(CSR_cases$What, levels= c( "Data" , "Model: 1 home seeded",  paste(paste("Model:", 2:10, sep = " "), "homes seeded", sep = " ")))



CSR_deaths <- rbind(data.frame(What = "Data", Date = weekly_csr_case_dates, y_data = Weekly_Deaths_Lothian$WeeklyDeaths, Type = "p", row.names=NULL)
                    ,data.frame(What = "Model: 1 home seeded", Date = weekly_csr_case_dates, y_data = seeded_1home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 2 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_2home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 3 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_3home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 4 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_4home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 5 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_5home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 6 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_6home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 7 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_7home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 8 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_8home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 9 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_9home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
                    ,data.frame(What = "Model: 10 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_10home_E_best_fit$Model_weekly_total_deaths, Type = "l", row.names=NULL)
)

CSR_deaths$What <- as.factor(CSR_deaths$What)
CSR_deaths$What <- factor(CSR_deaths$What, levels= c( "Data" , "Model: 1 home seeded",  paste(paste("Model:", 2:10, sep = " "), "homes seeded", sep = " ")))


C_cases <- rbind(data.frame(What = "Data", Date = weekly_csr_case_dates, y_data = c(NA,NA,weekly_ch_cases), Type = "p", row.names=NULL)
                 ,data.frame(What = "Model: 1 home seeded", Date = weekly_csr_case_dates, y_data = seeded_1home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 2 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_2home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 3 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_3home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 4 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_4home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 5 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_5home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 6 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_6home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 7 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_7home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 8 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_8home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 9 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_9home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
                 ,data.frame(What = "Model: 10 homes seeded", Date = weekly_csr_case_dates, y_data = seeded_10home_E_best_fit$Model_weekly_CH_cases, Type = "l", row.names=NULL)
)
C_cases$What <- as.factor(C_cases$What)

C_cases$What <- factor(C_cases$What, levels= c(  "Data" ,"Model: 1 home seeded",  paste(paste("Model:", 2:10, sep = " "), "homes seeded", sep = " ")))

C_deaths <- rbind(data.frame(What = "Data", Date = Lothian_CH_death_data$`Week commencing`, y_data = Lothian_CH_death_data$`COVID-19 deaths 2020`, Type = "p", row.names=NULL)
                  ,data.frame(What = "Model: 1 home seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_1home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 2 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_2home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 3 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_3home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 4 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_4home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 5 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_5home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 6 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_6home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 7 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_7home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 8 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_8home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 9 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_9home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
                  ,data.frame(What = "Model: 10 homes seeded", Date = Lothian_CH_death_data$`Week commencing`, y_data = seeded_10home_E_best_fit$Model_weekly_CH_deaths, Type = "l", row.names=NULL)
)
C_deaths$What <- as.factor(C_deaths$What)
C_deaths$What <- factor(C_deaths$What, levels= c( "Data" ,"Model: 1 home seeded",  paste(paste("Model:", 2:10, sep = " "), "homes seeded", sep = " ")))




# Function to plot model lines against the data

model_data_lines <- function(chosen_title, chosen_y_label, y_limits, data_frame){
  
  
  
  # if plotting subset of model fits
  # data_frame <- data_frame[data_frame$What== c("Data*","Model: 1 home seeded","Model: 2 homes seeded"),]
  
  
  values <- gg_color_hue(length(levels(data_frame$What))-1)
  values <- c("black", values)
  
  
  the_plot <- ggplot(data=data_frame,
                     aes(x=Date, y=y_data, color = (What))) +
    labs(title = chosen_title
         #,subtitle = "chosen_subtitle"
         ,x = "\nDate"
         ,y = chosen_y_label
    ) +
    theme_bw() +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
    ) +
    # theme(legend.key.size = unit(1, 'cm'), #change legend key size
    #       legend.key.height = unit(1, 'cm'), #change legend key height
    #       legend.key.width = unit(1, 'cm'), #change legend key width
    #       legend.title = element_text(size=14), #change legend title font size
    #       legend.text = element_text(size=10)) + #change legend text font size
    coord_cartesian(xlim = c(Date.sim[1], Date.sim[length(Date.sim)])
                    ,ylim = y_limits
    ) +
    geom_line() + geom_point() +
    # geom_point(data = data_frame[data_frame$Type == "p",], aes(x=Date, y=y_data)) +
    # geom_line(data = data_frame[data_frame$Type == "l",], aes(x=Date, y=y_data)) +
    # scale_colour_discrete(name = "")  +
    scale_colour_manual(name = "", values=values)
  
  return(the_plot)
}


CSR_cases<-CSR_cases[CSR_cases$What %in% c("Data","Model: 4 homes seeded"), ]
C_cases<-C_cases[C_cases$What %in% c("Data","Model: 4 homes seeded"), ]
CSR_deaths<-CSR_deaths[CSR_deaths$What %in% c("Data","Model: 4 homes seeded"), ]
C_deaths<-C_deaths[C_deaths$What %in% c("Data","Model: 4 homes seeded"), ]


case_ylim <- c(0, max(c(CSR_cases$y_data,C_cases$y_data),na.rm = T)+50)
death_ylim <- c(0,max(c(CSR_deaths$y_data,C_deaths$y_data),na.rm = T)+20)

CSR_cases_plot <- model_data_lines(chosen_title = "NHS Lothian", chosen_y_label = "Reported cases per week\n", y_limits = case_ylim, CSR_cases)
CSR_deaths_plot <- model_data_lines(chosen_title = "NHS Lothian", chosen_y_label = "Deaths per week\n", y_limits = death_ylim, CSR_deaths)
C_cases_plot <- model_data_lines(chosen_title = "NHS Lothian: CH residents", chosen_y_label = "Reported cases per week\n", y_limits = case_ylim, C_cases)
C_deaths_plot <- model_data_lines(chosen_title = "NHS Lothian: CH residents", chosen_y_label = "Deaths per week\n", y_limits = death_ylim, C_deaths)

Compare_fits_plot <- CSR_cases_plot + labs(tag = "(a)") + C_cases_plot + labs(tag = "(b)") + CSR_deaths_plot + labs(tag = "(c)") + C_deaths_plot + labs(tag = "(d)") + plot_layout(guides = "collect")

ggsave(plot = Compare_fits_plot, filename = "seeded_4home_plot.png"
       ,units = "mm", width=220, height = 166)
ggsave(plot = Compare_fits_plot, filename = "seeded_4home_plot.eps", device="eps"
       ,units = "mm", width=220, height = 166)



# 3b) Rt rates + Visitation ------------------





# First make plots of reproductive rates in best fitting parameter set, for each home seeded


# Each home seeded a different plot therefore need to
# make a data frame for each fitted model's reproductive rates

R_rates_1home_E <- data.frame(Date = Date.sim, "beta_c" = seeded_1home_E_best_fit$c_logi, "beta_s" = seeded_1home_E_best_fit$s_logi, "beta_r" = seeded_1home_E_best_fit$r_logi)
R_rates_1home_E <- R_rates_1home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")

R_rates_2home_E <- data.frame(Date = Date.sim, beta_c = seeded_2home_E_best_fit$c_logi, beta_s = seeded_2home_E_best_fit$s_logi, beta_r = seeded_2home_E_best_fit$r_logi)
R_rates_2home_E <- R_rates_2home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")

R_rates_3home_E <- data.frame(Date = Date.sim, beta_c = seeded_3home_E_best_fit$c_logi, beta_s = seeded_3home_E_best_fit$s_logi, beta_r = seeded_3home_E_best_fit$r_logi)
R_rates_3home_E <- R_rates_3home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")

R_rates_4home_E <- data.frame(Date = Date.sim, beta_c = seeded_4home_E_best_fit$c_logi, beta_s = seeded_4home_E_best_fit$s_logi, beta_r = seeded_4home_E_best_fit$r_logi)
R_rates_4home_E <- R_rates_4home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")


R_rates_5home_E <- data.frame(Date = Date.sim, beta_c = seeded_5home_E_best_fit$c_logi, beta_s = seeded_5home_E_best_fit$s_logi, beta_r = seeded_5home_E_best_fit$r_logi)
R_rates_5home_E <- R_rates_5home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")


R_rates_6home_E <- data.frame(Date = Date.sim, beta_c = seeded_6home_E_best_fit$c_logi, beta_s = seeded_6home_E_best_fit$s_logi, beta_r = seeded_6home_E_best_fit$r_logi)
R_rates_6home_E <- R_rates_6home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")


R_rates_7home_E <- data.frame(Date = Date.sim, beta_c = seeded_7home_E_best_fit$c_logi, beta_s = seeded_7home_E_best_fit$s_logi, beta_r = seeded_7home_E_best_fit$r_logi)
R_rates_7home_E <- R_rates_7home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")


R_rates_8home_E <- data.frame(Date = Date.sim, beta_c = seeded_8home_E_best_fit$c_logi, beta_s = seeded_8home_E_best_fit$s_logi, beta_r = seeded_8home_E_best_fit$r_logi)
R_rates_8home_E <- R_rates_8home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")


R_rates_9home_E <- data.frame(Date = Date.sim, beta_c = seeded_9home_E_best_fit$c_logi, beta_s = seeded_9home_E_best_fit$s_logi, beta_r = seeded_9home_E_best_fit$r_logi)
R_rates_9home_E <- R_rates_9home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")


R_rates_10home_E <- data.frame(Date = Date.sim, beta_c = seeded_10home_E_best_fit$c_logi, beta_s = seeded_10home_E_best_fit$s_logi, beta_r = seeded_10home_E_best_fit$r_logi)
R_rates_10home_E <- R_rates_10home_E %>%
  pivot_longer(!Date, names_to = "What", values_to = "y_data")

# Make colours of R rates same as their time series curves
R_rate_colours <- gg_color_hue(length(levels(CSR_cases$What))-1)
# R_rate_colours <- gg_color_hue(5)

# Function to make R rate plots
R_rate_plot <- function(chosen_title, chosen_col, data_frame){
  
  data_frame$What<-as.factor(data_frame$What)
  #levels(R_rates_4home_E$What)<-c("beta[c]", "beta[r]", "beta[s]")
  levels(data_frame$What)<-c("Care home residents", "General population","Workers")
  
  data_frame$What<-factor(data_frame$What, levels = c("Care home residents","Workers","General population"))
  
  the_plot <- ggplot(data=data_frame,
                     aes(x=Date, y=y_data, linetype = factor(What), color = factor(What))) +
    labs(title = ""#chosen_title
         #,subtitle = "chosen_subtitle"
         ,x = "\nDate"
         ,y = expression(paste(R[t]))
    ) +
    theme_bw() +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,legend.position = c(0.7,0.8)
          #,legend.key.size = unit(2.95, "mm")
          ,legend.key.width = unit(7.45, "mm")#unit(7.45, "mm")
          ,legend.text=element_text(size=11)
          ,legend.title = element_blank()
          ,axis.title.y = element_text(angle = 0
                                      ,size=20
                                      ,margin = margin(t = 0, r = 10, b = 0, l = 0)
                                      ,hjust = 0.5, vjust = 0.5)
          ,axis.title.x = element_text(size=20)   # change x label font size
          ,axis.text.x = element_text(size = 11)   # change x ticks font size
          ,axis.text.y = element_text(size = 11)
    ) +
    coord_cartesian(ylim = c(0,5)
    ) +
    geom_line(size=1) +
    scale_colour_discrete("", type = rep(chosen_col,3)) +
    scale_linetype_manual("", values=c(1:3))
  
  return(the_plot)
}


R_rates_1home_E_plot <- R_rate_plot("Model: 1 home seeded",R_rate_colours[1],R_rates_1home_E)
R_rates_2home_E_plot <- R_rate_plot("Model: 2 homes seeded",R_rate_colours[2],R_rates_2home_E)
R_rates_3home_E_plot <- R_rate_plot("Model: 3 homes seeded",R_rate_colours[3],R_rates_3home_E)
R_rates_4home_E_plot <- R_rate_plot("Model: 4 homes seeded",R_rate_colours[4],R_rates_4home_E)
R_rates_5home_E_plot <- R_rate_plot("Model: 5 homes seeded",R_rate_colours[5],R_rates_5home_E)
R_rates_6home_E_plot <- R_rate_plot("Model: 6 homes seeded",R_rate_colours[6],R_rates_6home_E)
R_rates_7home_E_plot <- R_rate_plot("Model: 7 homes seeded",R_rate_colours[7],R_rates_7home_E)
R_rates_8home_E_plot <- R_rate_plot("Model: 8 homes seeded",R_rate_colours[8],R_rates_8home_E)
R_rates_9home_E_plot <- R_rate_plot("Model: 9 homes seeded",R_rate_colours[9],R_rates_9home_E)
R_rates_10home_E_plot <- R_rate_plot("Model: 10 homes seeded",R_rate_colours[10],R_rates_10home_E)



# Visitation curve --


# need simtime - vector of time points
simTime = seq(from = 0, by = 1, length.out = 102)


# logi function
logi <- function(t, parameters){
  
  with(as.list(parameters),{
    
    l1 = 1/(1+exp(rate*(t-end)))
    l2 = 1/(1+exp(-rate*(t-start)))
    
    return((high-low)*l1*l2+low)
  })
}


seg_pars <- list( 
  
  C_pops = 109, 
  S_pops = 109,       # = C_pops, there is one shielder/staff sub-population per care home.
  R_pops = 1
)

sub_pop_sizes <- list(    # internal subpopulation sizes 
  
  C_internal = 48,                         # population of a single CH
  S_internal = 48,                         # population of a single staff population # = C_internal (assuming 1:1 resident:staff member ratio per home)
  R_internal = 907580-2*48*seg_pars$C_pops # population of a single rest population # (assuming CH resident population is 0.57-0.6% of population)
)

gamma_pars <-  list(start = -82,
                    end = 10,
                    rate = 3,
                    low = 0,
                    high = seeded_4home_E_best_fit$Optimal_gamma)


data_frame <- data.frame(Date = Date.sim, y_data = logi(simTime, gamma_pars)*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal, What = rep("Proportion of visitors day at care home"))

R_rate_colours <- gg_color_hue(length(levels(CSR_cases$What))-1)
chosen_col_1 <- R_rate_colours[4]#"#66a182"


gamma_plot <- ggplot(data=data_frame,
                     aes(x=Date, y=y_data, linetype = factor(What), color = factor(What))) +
  labs(x = "\nDate"
       ,y = expression(paste(gamma))
  ) +
  theme_bw() +
  theme(panel.grid.major = element_blank()
        ,panel.grid.minor = element_blank()
        ,panel.background = element_rect(colour = "black", size=0.1)
        ,legend.position = c(0.6,0.85)
        ,legend.text=element_text(size=11)
        ,axis.title.y = element_text(angle = 0
                                     ,size=20
                                     ,margin = margin(t = 0, r = 10, b = 0, l = 0)
                                     ,hjust = 0.5, vjust = 0.5)
        ,axis.title.x = element_text(size=20)
        ,axis.text.y = element_text(size = 11)
        ,axis.text.x = element_text(size = 11)
  ) +
  #coord_cartesian(ylim = c(0,1)) +
  geom_line(size=1) +
  scale_colour_discrete("", type = c(chosen_col_1)) +
  scale_linetype_manual("", values=c(1)) +
  scale_y_continuous(breaks = seq(0,seeded_4home_E_best_fit$Optimal_gamma*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal, length.out = 5)
                     ,labels = round(seq(0,seeded_4home_E_best_fit$Optimal_gamma*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal, length.out = 5),4)
  )



Rt_and_visitation <- R_rates_4home_E_plot + labs(tag=("(a)")) + gamma_plot + labs(tag=("(b)"))

ggsave(plot = Rt_and_visitation, filename = "Rt_and_visitation.png"
       ,units = "mm", width=280, height = 100)
ggsave(plot = Rt_and_visitation, filename = "Rt_and_visitation.eps", device = "eps"
       ,units = "mm", width=280, height = 100)







# 3c) Rt high values for C, S, R ---------------------

CH_R_rate_high <- rbind(data.frame(number_homes_seeded = 1, y_data = head(seeded_1home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 2, y_data = head(seeded_2home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 3, y_data = head(seeded_3home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 4, y_data = head(seeded_4home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 5, y_data = head(seeded_5home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 6, y_data = head(seeded_6home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 7, y_data = head(seeded_7home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 8, y_data = head(seeded_8home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 9, y_data = head(seeded_9home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 10, y_data = head(seeded_10home_E_best_fit$all_scenarios_sorted[,"CH.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
)

Rest_R_rate_high <- rbind(data.frame(number_homes_seeded = 1, y_data = head(seeded_1home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 2, y_data = head(seeded_2home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 3, y_data = head(seeded_3home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 4, y_data = head(seeded_4home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 5, y_data = head(seeded_5home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 6, y_data = head(seeded_6home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 7, y_data = head(seeded_7home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 8, y_data = head(seeded_8home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 9, y_data = head(seeded_9home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                        ,data.frame(number_homes_seeded = 10, y_data = head(seeded_10home_E_best_fit$all_scenarios_sorted[,"R.Rt.High"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
)

S_R_rate_high <- 0.5*(CH_R_rate_high + Rest_R_rate_high)

# table(data.frame(optimal_delta$number_homes_seeded, optimal_delta$y_data, optimal_epsilon$y_data, optimal_gamma$y_data, optimal_I0_R))

CH_R_rate_high_plot <- ggplot(CH_R_rate_high
                              ,aes(x=number_homes_seeded, y=y_data, fill = factor(number_homes_seeded), alpha = factor(index), color = factor(number_homes_seeded))) +
    labs(subtitle = ""#bquote("Care home resident"~R[t]~"pre-lockdown")
       #,subtitle = ""
       ,x = "\nHomes seeded"
       ,y = bquote(omega[high]^C)#expression(paste("Max ", R[t]))
  ) +
  theme_bw() +
  theme(panel.grid.major = element_blank()
        ,panel.grid.minor = element_blank()
        ,panel.background = element_rect(colour = "black", size=0.1)
        ,legend.position = ""
        ,axis.title.y = element_text(angle = 0,size = 15,margin = margin(t = 0, r = 5, b = 0, l = 0), hjust = 0.5, vjust = 0.5)
        # ,axis.title.x = element_text(size=20)
        # ,axis.text.y = element_text(size = 11)
        # ,axis.text.x = element_text(size = 11)
  ) +
  coord_cartesian(ylim = c(3.3,5)
  ) +
  geom_violin(trim=T, color = "black", alpha = 0.5) +
  geom_point(data = CH_R_rate_high[CH_R_rate_high$index %in% c(1), ], size=2, color = "black") +
  # scale_color_discrete("", type = R_rate_colours) +
  scale_alpha_discrete(range = c(1,1)) +
  
  # geom_dotplot(binaxis = "y", dotsize = 1.7, stackdir = "down",
  #              color = "black") +
  # scale_alpha_discrete(range = c(0.15,1)) +
  
  scale_fill_discrete("", type = R_rate_colours) +
  scale_x_continuous(breaks = seq(1,10, by = 1)) +
  scale_y_continuous(breaks = seq(3.3,5, by = 0.2))


S_R_rate_high_plot <- ggplot(data=S_R_rate_high
                             ,aes(x=number_homes_seeded, y=y_data, fill = factor(number_homes_seeded), alpha = factor(index), color = factor(number_homes_seeded))) +
  labs(subtitle = ""#bquote("Worker"~R[t]~"pre-lockdown")
       #,subtitle = ""
       ,x = "\nHomes seeded"
       ,y = bquote(omega[high]^S)#expression(paste("Max ", R[t]))
  ) +
  theme_bw() +
  theme(panel.grid.major = element_blank()
        ,panel.grid.minor = element_blank()
        ,panel.background = element_rect(colour = "black", size=0.1)
        ,legend.position = ""
        ,axis.title.y = element_text(angle = 90, margin = margin(t = 0, r = 5, b = 0, l = 0), hjust = 0.5, vjust = 0.5)
  ) +
  coord_cartesian(ylim = c(3.3,5)
  ) +
  # geom_line(colour = "black", size = 1) + geom_point(size=4) +
  
  geom_violin(trim=T, color = "black", alpha = 0.5) +
  geom_point(data = S_R_rate_high[S_R_rate_high$index %in% c(1), ], size=2, color = "black") +
  # scale_color_discrete("", type = R_rate_colours) +
  scale_alpha_discrete(range = c(1,1)) +
  
  # geom_dotplot(binaxis = "y", dotsize = 1.7, stackdir = "down",
  #              color = "black") +
  # scale_alpha_discrete(range = c(0.15,1)) +
  
  scale_fill_discrete("", type = R_rate_colours) +
  scale_x_continuous(breaks = seq(1,10, by = 1)) +
  scale_y_continuous(breaks = seq(3.3,5, by = 0.2))
  


Rest_R_rate_high_plot <- ggplot(data=Rest_R_rate_high
                                ,aes(x=number_homes_seeded, y=y_data, fill = factor(number_homes_seeded), alpha = factor(index), color = factor(number_homes_seeded))) +
  labs(subtitle = ""#bquote("General population"~R[t]~"pre-lockdown")
       #,subtitle = ""
       ,x = "\nHomes seeded"
       ,y = bquote(omega[high]^G)#expression(paste("Max ", R[t]))
  ) +
  theme_bw() +
  theme(panel.grid.major = element_blank()
        ,panel.grid.minor = element_blank()
        ,panel.background = element_rect(colour = "black", size=0.1)
        ,legend.position = ""
        ,axis.title.y = element_text(angle = 0,size = 15,margin = margin(t = 0, r = 5, b = 0, l = 0), hjust = 0.5, vjust = 0.5)
  ) +
  coord_cartesian(ylim = c(3.3,5)
  ) +
  geom_violin(trim=T, color = "black", alpha = 0.5) +
  geom_point(data = Rest_R_rate_high[Rest_R_rate_high$index %in% c(1), ], size=2, color = "black") +
  # scale_color_discrete("", type = R_rate_colours) +
  scale_alpha_discrete(range = c(1,1)) +
  
  # geom_dotplot(binaxis = "y", dotsize = 1.7, stackdir = "down",
  #              color = "black") +
  # scale_alpha_discrete(range = c(0.15,1)) +
  
  scale_fill_discrete("", type = R_rate_colours) +
  scale_x_continuous(breaks = seq(1,10, by = 1)) +
  scale_y_continuous(breaks = seq(3.3,5, by = 0.2))

Rt_high_plots <- CH_R_rate_high_plot + S_R_rate_high_plot + Rest_R_rate_high_plot

# ggsave(plot = Rt_high_plots, filename = "Rt_high_plots.png"
#        ,units = "mm", width=303, height = 135)



# 3d) epsilon --------

optimal_epsilon <- rbind(data.frame(number_homes_seeded = 1, y_data = head(seeded_1home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 2, y_data = head(seeded_2home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 3, y_data = head(seeded_3home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 4, y_data = head(seeded_4home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 5, y_data = head(seeded_5home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 6, y_data = head(seeded_6home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 7, y_data = head(seeded_7home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 8, y_data = head(seeded_8home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 9, y_data = head(seeded_9home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                         ,data.frame(number_homes_seeded = 10, y_data = head(seeded_10home_E_best_fit$all_scenarios_sorted[,"epsilon.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
)


optimal_epsilon_plot <- ggplot(data=optimal_epsilon
                               ,aes(x=number_homes_seeded, y=y_data, fill = factor(number_homes_seeded), alpha = factor(index), color = factor(number_homes_seeded))) +
  labs(#title = ""
       subtitle = ""#"Proportion of a CH's staff shared"
       ,x = "\n Homes seeded"
       ,y = expression(paste(epsilon))
  ) +
  theme_bw() +
  theme(panel.grid.major = element_blank()
        ,panel.grid.minor = element_blank()
        ,panel.background = element_rect(colour = "black", size=0.1)
        ,legend.position = ""
        ,axis.title.y = element_text(angle = 0, size = 18,margin = margin(t = 0, r = 10, b = 0, l = 0), hjust = 0.5, vjust = 0.5)
  ) +
  coord_cartesian(ylim = c(0,0.5)) +
  # geom_line(colour = "black", size = 1) + geom_point(size=4) +
  # scale_colour_discrete("", type = R_rate_colours) +
  # scale_x_continuous(breaks = seq(1,10, by = 1)) +
  # scale_y_continuous(breaks = seq(0,0.6, by = 0.1))
  # geom_line(colour = "black", size = 1) + geom_point(size=4) +
  
  geom_violin(trim=T, color = "black", alpha = 0.5) +
  geom_point(data = optimal_epsilon[optimal_epsilon$index %in% c(1), ], size=2, color = "black") +
  # scale_color_discrete("", type = R_rate_colours) +
  scale_alpha_discrete(range = c(1,1)) +
  
  # geom_dotplot(binaxis = "y", dotsize = 1.7, stackdir = "down",
  #              color = "black") +
  # scale_alpha_discrete(range = c(0.15,1)) +
  
  scale_fill_discrete("", type = R_rate_colours) +
  scale_x_continuous(breaks = seq(1,10, by = 1)) +
  scale_y_continuous(breaks = seq(0,0.6, by = 0.1))



# 3e) visitation (pre-lockdown proportion of day) ---------



optimal_gamma <- rbind(data.frame(number_homes_seeded = 1, y_data = head(seeded_1home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 2, y_data = head(seeded_2home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 3, y_data = head(seeded_3home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 4, y_data = head(seeded_4home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 5, y_data = head(seeded_5home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 6, y_data = head(seeded_6home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 7, y_data = head(seeded_7home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 8, y_data = head(seeded_8home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 9, y_data = head(seeded_9home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                       ,data.frame(number_homes_seeded = 10, y_data = head(seeded_10home_E_best_fit$all_scenarios_sorted[,"gamma.vals"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
)


sub_pop_sizes <- list(    # internal subpopulation sizes 
  
  C_internal = 48,                         # population of a single CH
  S_internal = 48,                         # population of a single staff population # = C_internal (assuming 1:1 resident:staff member ratio per home)
  R_internal = 907580-2*48*109 # population of a single rest population # (assuming CH resident population is 0.57-0.6% of population)
)

optimal_gamma_plot <- ggplot(data=optimal_gamma,
                             aes(x=number_homes_seeded, y=y_data*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal, fill = factor(number_homes_seeded), alpha = factor(index), color = factor(number_homes_seeded))) +
  labs(#title = ""
       subtitle = ""#"Proportion of visitors day at care home"
       ,x = "\nHomes seeded"
       ,y = expression(paste(omega[high]^gamma))
  ) +
  theme_bw() +
  theme(panel.grid.major = element_blank()
        ,panel.grid.minor = element_blank()
        ,panel.background = element_rect(colour = "black", size=0.1)
        ,legend.position = ""
        ,axis.title.y = element_text(angle =0, size = 15,margin = margin(t = 0, r = 10, b = 0, l = 0), hjust = 0.5, vjust = 0.5)
  ) +
  coord_cartesian(ylim = c(0,0.2)) +
  geom_violin(trim=T, color = "black", alpha = 0.5) +
  geom_point(data = optimal_gamma[optimal_gamma$index %in% c(1), ], size=2, color = "black") +
  # scale_color_discrete("", type = R_rate_colours) +
  scale_alpha_discrete(range = c(1,1)) +
  
  # geom_dotplot(binaxis = "y", dotsize = 1.7, stackdir = "down",
  #              color = "black") +
  # scale_alpha_discrete(range = c(0.15,1)) +
  
  scale_fill_discrete("", type = R_rate_colours) +
  scale_x_continuous(breaks = seq(1,10, by = 1)) +
  scale_y_continuous(breaks = seq(0,0.16, by = 0.04)) 
  # scale_y_continuous(breaks = seq(0,4/24, length.out = 5)
  #                    #,labels = round(seq(0,4/24, length.out = 5),4)
  #                    ,labels = expression(0,over(1,24),over(2,24),over(3,24),over(4,24))
  # )


# 3f) general pop seeding ----------------------
optimal_I0_R <- rbind(data.frame(number_homes_seeded = 1, y_data = head(seeded_1home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 2, y_data = head(seeded_2home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 3, y_data = head(seeded_3home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 4, y_data = head(seeded_4home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 5, y_data = head(seeded_5home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 6, y_data = head(seeded_6home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 7, y_data = head(seeded_7home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 8, y_data = head(seeded_8home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 9, y_data = head(seeded_9home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                      ,data.frame(number_homes_seeded = 10, y_data = head(seeded_10home_E_best_fit$all_scenarios_sorted[,"initial.R.Inf"],number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
)

optimal_I0_R_plot <- ggplot(data=optimal_I0_R
                            ,aes(x=number_homes_seeded, y=y_data, fill = factor(number_homes_seeded), alpha = factor(index), color = factor(number_homes_seeded))) +
  labs(#title = ""
       subtitle = ""#"General population seeding"
       ,x = "\nHomes seeded"
       ,y = bquote(E[G](0))#expression(paste(I[0]))
  ) +
  theme_bw() +
  theme(panel.grid.major = element_blank()
        ,panel.grid.minor = element_blank()
        ,panel.background = element_rect(colour = "black", size=0.1)
        ,legend.position = ""
        ,axis.title.y = element_text(angle = 0, size = 13,margin = margin(t = 0, r = 5, b = 0, l = 0), hjust = 0.5, vjust = 0.5)
  ) +
  coord_cartesian(ylim = c(100,180)
  ) +
  geom_violin(trim=T, color = "black", alpha = 0.5) +
  geom_point(data = optimal_I0_R[optimal_I0_R$index %in% c(1), ], size=2, color = "black") +
  # scale_color_discrete("", type = R_rate_colours) +
  scale_alpha_discrete(range = c(1,1)) +
  
  # geom_dotplot(binaxis = "y", dotsize = 1.7, stackdir = "down",
  #              color = "black") +
  # scale_alpha_discrete(range = c(0.15,1)) +
  
  scale_fill_discrete("", type = R_rate_colours) +
  scale_x_continuous(breaks = seq(1,10, by = 1)) +
  scale_y_continuous(breaks = seq(100,180, by =20))


opt_epsilon_gamma_I0R_plot <- optimal_epsilon_plot + optimal_gamma_plot + optimal_I0_R_plot +  plot_layout(ncol = 3)


# ggsave(plot = opt_epsilon_gamma_I0R_plot, filename = "opt_epsilon_gamma_I0R_plot.png"
#        ,units = "mm", width=303, height = 135)


# 3g) aggregated sum of squares error --------------


Least_Square_Error <- rbind(data.frame(number_homes_seeded = 1, y_data = head(seeded_1home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 2, y_data = head(seeded_2home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 3, y_data = head(seeded_3home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 4, y_data = head(seeded_4home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 5, y_data = head(seeded_5home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 6, y_data = head(seeded_6home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 7, y_data = head(seeded_7home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 8, y_data = head(seeded_8home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 9, y_data = head(seeded_9home_E_best_fit$all_LS_sorted, number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
                            ,data.frame(number_homes_seeded = 10, y_data = head(seeded_10home_E_best_fit$all_LS_sorted ,number_top_scenarios), index = c(1, rep(0,number_top_scenarios-1)), row.names=NULL)
)


Least_Square_Error_plot <- ggplot(data=Least_Square_Error
                                  ,aes(x=number_homes_seeded, y=y_data, fill = factor(number_homes_seeded), alpha = factor(index), color = factor(number_homes_seeded))) +
  labs(subtitle = ""
       ,x = "\nHomes seeded"
       ,y = "Aggregated SSE\n"
  ) +
  theme_bw() +
  theme(panel.grid.major = element_blank()
        ,panel.grid.minor = element_blank()
        ,panel.background = element_rect(colour = "black", size=0.1)
        ,legend.position = ""
        ,axis.title.y = element_text(angle = 0,
                                     #size = 20,
                                     margin = margin(t = 0, r = 5, b = 0, l = 0), 
                                     hjust = 0.5, vjust = 0.5)
        # ,axis.title.x = element_text(size=20)
        # ,axis.text.y = element_text(size = 11)
        # ,axis.text.x = element_text(size = 11)
  ) +
  geom_violin(trim=T, color = "black", alpha = 0.5) +
  geom_point(data = Least_Square_Error[Least_Square_Error$index %in% c(1), ], size=2, color = "black") +
  # scale_color_discrete("", type = R_rate_colours) +
  scale_alpha_discrete(range = c(1,1)) +
  
  # geom_dotplot(binaxis = "y", dotsize = 1.7, stackdir = "down",
  #              color = "black") +
  # scale_alpha_discrete(range = c(0.15,1)) +
  
  scale_fill_discrete("", type = R_rate_colours) +
  scale_x_continuous(breaks = seq(1,10, by = 1)) 


ggsave(plot = Least_Square_Error_plot, filename = "Least_Square_Error_plot.png"
       ,units = "mm", width=130, height = 100)
ggsave(plot = Least_Square_Error_plot, filename = "Least_Square_Error_plot.eps", device = "eps"
       ,units = "mm", width=130, height = 100)






all_pars <-  CH_R_rate_high_plot + labs(tag="(a)") +
  # S_R_rate_high_plot + 
  Rest_R_rate_high_plot + labs(tag="(b)") +
  # Rest_Rt_rate_plot + 
  optimal_epsilon_plot + labs(tag="(c)") + optimal_gamma_plot + labs(tag="(d)") +
  optimal_I0_R_plot + labs(tag="(e)") +
  plot_layout(ncol = 3)

ggsave(plot = all_pars, filename = "all_pars.png"
       ,units = "mm", width=300, height = 200)

