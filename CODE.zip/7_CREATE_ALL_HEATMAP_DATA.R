# Code Description ############################################################
# Date: 09_08_2021
# Written by: Matthew Baister, Ewan McTaggart


# Sensitivity analysis of two parameters varied on change in 
# final deaths and change in aggregated sum of squared errors (SSEs)
# (looking at the aggregared SSE and shifting a parameter can 
# indicate the stability of the fit)

# To do this we'll make heatmaps/contour plots: x and y axis will be two 
# parameters, z axis final deaths/LSE

# This script creates the data frames

rm(list = ls())

# 1) Preamble - Source scripts with SEIRD functions, read in parameters from script 2_SEIRD
# 2) Listed here are the parameters we test the sensitivity of (see baseline vector). Set baseline vector by loading in data
# 3) Wrapper which calculates model solution for a given set of parameters and returns final number of deaths (C, S, R) and LS aggregate
# 4) Create the data frames for heatmaps

# 1) Preamble ----------------------------------------------------------


# if (!"parallel" %in% installed.packages())
#   install.packages("parallel")
library(parallel)               # Library with parallelised verisions of lapply etc. For calculating model output for different sets of parameters.


# import the SEIRD functions and baseline parameters from the R scripts:
source('2_SEIRD.R')

# Read in case and death data to calculate least squares against:
source('READ_DATA.R')


# 2) Parameters we could vary in sensitivity analysis ---------------------

baseline_names<-c("beta_rr_high"
                  ,"beta_rr_low"
                  ,"beta_rr_rate"
                  ,"beta_rr_end"
                  ,"beta_c_high"
                  ,"beta_c_low"
                  ,"beta_c_rate"
                  ,"beta_c_end"
                  ,"delta"
                  ,"epsilon"
                  ,"gamma"
                  ,"initial_infected_R_total"
                  ,"latency"
                  ,"tau")

# if loading in parameters from the best fit in script 7...

load("seeded_4home_E_best_fit.RData")
seeded_xhome_best_fit <- seeded_4home_E_best_fit

baseline<-c(     # create vector of baseline parameter values
  
  # beta_rr high
  as.numeric(seeded_xhome_best_fit$All_params["R.Rt.High"])
  
  # beta_rr low
  ,baseRLow_pars$beta_rr
  
  # beta_rr rate
  ,as.numeric(seeded_xhome_best_fit$All_params["R.Rt.Rate"])
  
  # beta_rr end
  ,as.numeric(seeded_xhome_best_fit$All_params["R.Rt.End"])
  
  # beta_c high
  ,as.numeric(seeded_xhome_best_fit$All_params["CH.Rt.High"])
  
  # beta_c low
  ,as.numeric(seeded_xhome_best_fit$All_params["CH.Rt.Low"])
  
  # beta_c rate
  ,as.numeric(seeded_xhome_best_fit$All_params["CH.Rt.Rate"])
  
  # beta_c end
  ,as.numeric(seeded_xhome_best_fit$All_params["CH.Rt.End"])
  
  # delta
  ,as.numeric(seeded_xhome_best_fit$All_params["delta.vals"])
  
  # epsilon
  ,as.numeric(seeded_xhome_best_fit$All_params["epsilon.vals"])
  
  # gamma
  ,as.numeric(seeded_xhome_best_fit$All_params["gamma.vals"])
  
  # initial infected R total
  ,as.numeric(seeded_xhome_best_fit$All_params["initial.R.Inf"])
  
  # latency
  ,parms_passed$latency
  
  # tau
  ,parms_passed$Tau
)
names(baseline) <- baseline_names


# baseline final deaths in each popualtion
# baseline_deaths <- sensitivity_death_output(baseline_final_deaths) 

# 3) Function that generates a single output of sensitivity analysis -------------


sensitivity_death_output <-  function(row_parameter_values, parms_passed){        
  
  # Function which takes a (named) vector of parameter values, 
  # then for each population (C, S, R) calculates;
  
  # - the final number of deaths by the end of the simulation (after 102 time steps)
  
  # The result is returned in vector form like this 
  # c(C_total, S_total, R_total)
  
  
  # The function replaces any items ran in 2_SEIRD which involve
  # the parameters being varied
  
  # Replace old parameter values with new values
  # from row_parameter_values:
  
  
  baseRHigh_pars <- list(
    
    beta_c = row_parameter_values["beta_c_high"], # internal Care home reproduction number
    beta_cc = row_parameter_values["beta_c_high"],  # between Care home reproduction number
    
    beta_cs = row_parameter_values["beta_c_high"], # Care home to Shielder/Staff reproduction number
    beta_sc = row_parameter_values["beta_c_high"], # Staff to Care home reproduction number (assume equal to beta_cs)
    
    
    # Remaining Shielder/Staff transmission rates 
    
    beta_s = (row_parameter_values["beta_c_high"]+row_parameter_values["beta_rr_high"])/2,   # internal Staff reproduction number
    beta_ss = (row_parameter_values["beta_c_high"]+row_parameter_values["beta_rr_high"])/2,  # between Staff reproduction number (could be higher than beta_rr due to mixing in workplace?)
    
    # Remaining Rest of Population transmission rates 
    beta_rr = row_parameter_values["beta_rr_high"] # rest of population to rest of population reproduction number    #4.56 is latency = 5.8 instead of 8
  )
  
  baseRLow_pars <- list(
    
    beta_c  = row_parameter_values["beta_c_low"], # internal Care home reproduction number
    beta_cc = row_parameter_values["beta_c_low"],  # between Care home reproduction number
    
    beta_cs = row_parameter_values["beta_c_low"],  # Care home to Shielder/Staff treproduction number
    beta_sc = row_parameter_values["beta_c_low"], # Staff to Care home reproduction number (assume equal to beta_cs)
    
    # Remaining Shielder/Staff reproduction number
    
    beta_s = (row_parameter_values["beta_c_low"]+row_parameter_values["beta_rr_low"])/2, # internal Staff reproduction number
    beta_ss = (row_parameter_values["beta_c_low"]+row_parameter_values["beta_rr_low"])/2, # between Staff reproduction number (could be higher than beta_rr due to mixing in workplace?)
    
    # Remaining Rest of Population reproduction numbers
    beta_rr = row_parameter_values["beta_rr_low"] # rest of population to rest of population reproduction number    #0.7 if latency = 5.8 instead of 8
  )
  
  
  baseEnd_pars <- list(
    
    c = row_parameter_values["beta_c_end"],   # internal Care home logi function end time
    cc = row_parameter_values["beta_c_end"],  # between Care home logi function end time
    cs = row_parameter_values["beta_c_end"],  # Care home to Shielder/Staff logi function end time
    sc = row_parameter_values["beta_c_end"],  # Staff to Care home logi function end time
    
    # Remaining Shielder/Staff logi function end times
    
    s = row_parameter_values["beta_c_end"],   # internal Staff logi function end time
    ss = row_parameter_values["beta_c_end"],  # between Staff logi function end time
    
    # # Note - Staff to rest of population logi function end time = rr
    rr = row_parameter_values["beta_rr_end"]   # rest of population to rest of population logi function end time
  )
  
  
  baseRate_pars <- list(
    
    c = row_parameter_values["beta_c_rate"],  # internal Care home logi function rate value
    cc = row_parameter_values["beta_c_rate"], # between Care home logi function rate value
    cs = row_parameter_values["beta_c_rate"], # Care home to Shielder/Staff logi function rate value
    sc = row_parameter_values["beta_c_rate"], # Staff to Care home logi function rate value
    
    # Remaining Shielder/Staff logi function rate value
    
    s = row_parameter_values["beta_c_rate"],  # internal Staff logi function rate value
    ss = row_parameter_values["beta_c_rate"], # between Staff logi function rate value
    rr = row_parameter_values["beta_rr_rate"]  # rest of population to rest of population logi function rate value
  )
  
  # num_homes_infected <- ... # don't need to set this as from running 2_SEIRD "num_homes_infected" is in the environment
  
  # num_S_infected <- ... # same logic
  
  Infect_init <- list(     # initial infected parameters
    
    # The initial total infected (reported + unreported, or symptomatic + asymptomatic)
    # in each subpopulation (e.g. R_total_infected) is split evenly between the 
    # subpopulations in that population that have an initial outbreak (e.g. R_subs_inf).
    
    C_subs_inf = C_initial_dist(seg_pars, num_homes_infected),  # C subpopulations that all initial C cases (C_total_infected) is split evenly between. Length must be less than or equal to seg_pars$C_pops. If no subpopulations have outbreak set as NULL.
    S_subs_inf = C_initial_dist(seg_pars, num_S_infected),  # S subpopulations that all initial S cases (S_total_infected) is split evenly between. Length must be less than or equal to seg_pars$S_pops. If no subpopulations have outbreak set as NULL.
    R_subs_inf = c(1),                   # R subpopulations that all initial R cases (R_total_infected) is split evenly between. Length must be less than or equal to seg_pars$R_pops. If no subpopulations have outbreak set as NULL.
    
    C_total_infected = num_homes_infected/(1-asymptomatic_proportions$C_asymp),  # i.e. assuming 1 symptomatic case in "num_homes_infected" homes                  # total initial infected across all care home sub-populations
    S_total_infected = num_S_infected/(1-asymptomatic_proportions$S_asymp),                     # total initial infected across all staff sub-populations
    R_total_infected = row_parameter_values["initial_infected_R_total"]       # total initial infected across all rest sub-populations
    
    # Note: this requires (initial total infected + initital total exposed)/(number subpopulations with initial outbreak) = total infected or exposed in subpopulation initially < = capacity of that subpopulation
    #       for every subpopulation of C, S and R.
    
  )
  
  parms_passed$Travel_pars <- list(    
    # Parameters used to create the travel matrix, T. 
    # This is the matrix whose [i,j] element is the
    # the proportion of subpopulation i who travel to j
    
    # To create this matrix these get passed into create_TravelMatrix
    
    # note that these proportions are "averaged out over a whole day"
    
    delta = row_parameter_values["delta"],            # Proportion of staff who are at CH's instead of mixing with Rest. Controls how many staff are at each CH on average.
    # epsilon =           # Proportion of a CH's staff who work at other homes
    # gamma =             # Proportion of Rest that visit each CH. Total proportion who visit is seg_pars$C_pops*gamma. General form of gamma = x(sub_pop_sizes$C_internal/sub_pop_sizes$R_internal)(y), where x is the number of visitors per day per resident, and y is the proportion of a day a visitor spends at a care home
    
    # epsilon and gamma are time dependent (we model each of their trajectories using the logi function)
    # .....
    epsilon_pars =  list(start = -82,
                         end = row_parameter_values["beta_rr_end"],
                         rate =  row_parameter_values["beta_rr_rate"], 
                         low = row_parameter_values["epsilon"], 
                         high = row_parameter_values["epsilon"]),
    
    gamma_pars =  list(start = -82,        # gamma is the proportion of Rest that visit each CH. Total proportion who visit is seg_pars$C_pops*gamma. General form of gamma = x(sub_pop_sizes$C_internal/sub_pop_sizes$R_internal)(y), where x is the number of visitors per day per resident, and y is the proportion of a day a visitor spends at a care home
                       end = 10,
                       rate = 3,
                       low = 0,
                       high = row_parameter_values["gamma"])
    
                        # Total number of homes some proportion of a CH's staff work at (including "their" home)
  )
  
  
  
  
  
  # replace parameter lists/matrices that get passed to functions ---
  
  # generate initial SEIRD values per sub-population as a vector
  SEIRD_vectors <- create_SEIRDVector(seg_pars, sub_pop_sizes, Infect_init, asymptomatic_proportions)
  
  ## FIRST WAVE matrices ##
  
  # Create matrix of baseRLow values
  parms_passed$baseRLow_matrix <- create_RMatrix(baseRLow_pars,seg_pars,between_pars)
  
  # create matrix of baseRHigh Values
  parms_passed$baseRHigh_matrix <- create_RMatrix(baseRHigh_pars, seg_pars,between_pars)
  
  # create matrix of baseEnd values
  parms_passed$baseEnd_matrix <- create_WaveMatrix(baseEnd_pars, seg_pars)
  
  # create matrix of baseRate values
  parms_passed$baseRate_matrix <- create_WaveMatrix(baseRate_pars, seg_pars)
  
  
  
  ## OTHER parameter lists ##
  
  parms_passed$latency <- row_parameter_values["latency"]
  parms_passed$Tau <- row_parameter_values["tau"]
  
  
  # Next calculate the model solution... 
  # (note that only need the start and end times if calculating final deaths)
  
  # Run sim
  sims_multi_logi <- ode(y = SEIRD_vectors, times = simTime, func = seird_multi_logi, parms = parms_passed)
  
  # array holds SEIRD values, e.g., S_c = Carehome_values[,,1], E_c = Carehome_values[,,2], etc.
  Carehome_values <- careHome_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
  
  # array holds SEIRD values, e.g., S_s = Shielder_values[,,1], E_s = Shielder_values[,,2], etc.
  Shielder_values <- Shielder_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
  
  # array holds SEIRD values, e.g., S_R = Shielder_values[,,1], E_R = Shielder_values[,,2], etc.
  Rest_values <- Rest_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
  
  
  # Now calculate the total number of deaths at the end of the simulation 
  
  
  # CH population
  C_total<-rowSums(Carehome_values[,,6])[length(rowSums(Carehome_values[,,6]))]
  
  # Staff population
  S_total<-rowSums(Shielder_values[,,6])[length(rowSums(Shielder_values[,,6]))]
  
  # Rest population
  R_total<-Rest_values[,,6][length(Rest_values[,,6])]
  
  # Weekly Lothian CSR cases  
  LSE_CSR_cases_data <- sum( ( diff(c(0, (cumsum(rowSums(Shielder_values[,,3])+Rest_values[,,3]+rowSums(Carehome_values[,,3]))/parms_passed$Tau)[seq(4, length(Date.sim) , by  = 7 )]))  - weekly_csr_cases)^2 ) 
  
  
  
  # Now calculate aggregated sum of squares error
  
  # Weekly Lothian CSR deaths
  LSE_CSR_death_data <- sum((diff(c(0,(rowSums(Shielder_values[,,6])+Rest_values[,,6]+rowSums(Carehome_values[,,6]))[seq(4, length(Date.sim) , by  = 7 )])) - 
                               Weekly_Deaths_Lothian$WeeklyDeaths)^2)
  
  
  # Weekly CH cases
  
  LSE_ch_case_data <- sum((diff(c( cumsum(rowSums(Carehome_values[,,3])/parms_passed$Tau)[11],
                                   cumsum(rowSums(Carehome_values[,,3])/parms_passed$Tau)[Date.sim %in% weekly_ch_case_dates])) - weekly_ch_cases )^2)
  
  # Weekly CH deaths
  LSE_ch_death_data <- sum( ( diff(c(0,(rowSums(Carehome_values[,,6])[seq(4, length(Date.sim) , by  = 7 )])))-(Lothian_CH_death_data$`COVID-19 deaths 2020`) )^2 )
  
  
  # Sum of all least squares errors
  
  LSE_aggregate <- LSE_CSR_cases_data + LSE_CSR_death_data + LSE_ch_case_data + LSE_ch_death_data
  
  
  
  return(list("C" = C_total, "S" = S_total, "R" = R_total, "LS" = LSE_aggregate)) 
  
  # returns a vector, where each element is the final deaths for C, S, and R respectively
  
}


# Function that makes heatmaps given two vectors ---------------

heatmap <- function(variable_x, variable_y){      
  
  
  # # Example for testing
  # 
  #  beta_rr_high <- c(3,4)
  #  names(beta_rr_high)<-c("beta_rr_high")
  # 
  #  beta_rr_low <- c(0.5, 0.6)
  #  names(beta_rr_low)<-c("beta_rr_low")
  # 
  #  variable_x <- beta_rr_high
  #  variable_y <- beta_rr_low
  
  

  # use these below to refer to the column of parameters being varied
  # and also as x and y labels for the plots
  x_label <- names(variable_x)[1]
  y_label <- names(variable_y)[1]
  
  
  # create all permutations of the parameters being varied
  # combinations <- crossing(variable_x,variable_y)
  combinations <- expand.grid(variable_x = variable_x,variable_y = variable_y)
  
  
  combination_matrix <- matrix(rep(baseline,nrow(combinations)), byrow = T,
                               nrow = nrow(combinations), ncol =length(baseline))
  
  colnames(combination_matrix) <- names(baseline)
  
  combination_matrix[,names(variable_x)[1]]<-combinations[,1]
  combination_matrix[,names(variable_y)[1]]<-combinations[,2]
  
  
  combination_list <- as.list(as.data.frame(t(combination_matrix)))
  
  combination_list <- lapply(1:nrow(combination_matrix)
                             ,function(x){ names(combination_list[[x]]) <- colnames(combination_matrix)
                                          return(combination_list[[x]]) })
  
  
  
  # parallel calculation

  # number of cores -------
  no_cores <- 40

  # Initiate cluster
  cl <- makeCluster(no_cores, type = "FORK")

  big_calculation <- parLapply(cl, combination_list,
                             function(input_list){sensitivity_death_output(input_list
                                                         ,parms_passed)}
  )

  stopCluster(cl)
  
  
  
  # # non-parallel calculation
  # 
  # big_calculation <- lapply(combination_list,
  #                              function(input_list){sensitivity_death_output(input_list
  #                                                                            ,parms_passed)}
  # 
  # 
  # )
  
  
  
  final_deaths <- matrix(unlist(big_calculation), ncol=4, byrow=T)[,c(1,2,3)]
  colnames(final_deaths) <- c("C","S","R")
  
  
  LS_agg <- matrix(unlist(big_calculation), ncol=4, byrow=T)[,4]
  
  plot_names <- c("Resident deaths", "Staff deaths", "Rest deaths", "Least squares error")
  
  storage<-list()
  
  
  names(combinations)<-c(x_label,y_label)
  
  storage[[1]]<-c(NA)
  storage[[2]]<-c(NA)
  storage[[3]]<-c(NA)
  storage[[4]]<-c(NA)
  
  # also store data
  
  storage[[5]] <- data.frame(combinations, "C" = final_deaths[,1])
  storage[[6]] <- data.frame(combinations, "S" = final_deaths[,2])
  storage[[7]] <- data.frame(combinations, "R" = final_deaths[,3])
  storage[[8]] <- data.frame(combinations, "LS" = LS_agg)
  
  
  names(storage)<-c(plot_names, paste(plot_names, "data"))
  
  return(storage)
  
}
  


# 4a) Parameter ranges for heatmaps -------------

num_values <- 50 # number of each continuous parameter to consider

{
beta_rr_high <- seq(3,4, length.out = num_values)
names(beta_rr_high)<-c("beta_rr_high")

beta_rr_low <- seq(0.1,1.1, length.out = num_values)
names(beta_rr_low)<-c("beta_rr_low")

beta_rr_rate <- seq(0,3, length.out = num_values)
names(beta_rr_rate)<-c("beta_rr_rate")

beta_rr_end <- seq(22-4, 22+4, by = 1)
names(beta_rr_end)<-c("beta_rr_end")



beta_s_high <- seq(3,6, length.out = num_values)
names(beta_s_high)<-c("beta_s_high")

beta_s_low <- seq(0.1,1.1, length.out = num_values)
names(beta_s_low)<-c("beta_s_low")

beta_s_rate <- seq(0,3, length.out = num_values)
names(beta_s_rate)<-c("beta_s_rate")

beta_s_end <- seq(42-4, 42+4, by = 1)
names(beta_s_end)<-c("beta_s_end")




beta_c_high <- seq(3.5,5, length.out = num_values)
names(beta_c_high)<-c("beta_c_high")

beta_c_low <- seq(0.1,1.1, length.out = num_values)
names(beta_c_low)<-c("beta_c_low")

beta_c_rate <- seq(0,3, length.out = num_values)
names(beta_c_rate)<-c("beta_c_rate")

beta_c_end <- seq(42-4, 42+4, by = 1)
names(beta_c_end)<-c("beta_c_end")



initial_infected_R_total <- seq(100, 200, length.out = num_values)
names(initial_infected_R_total)<-c("initial_infected_R_total")

number_CHs_with_outbreak <- seq(1, seg_pars$S_pops, by = 1)    # chosen so that the homes are equally spaced
names(number_CHs_with_outbreak)<-c("number_CHs_with_outbreak")

size_initial_CH_outbreak <- seq(1, 48, by = 1)
names(size_initial_CH_outbreak) <- c("size_initial_CH_outbreak")

number_S_with_outbreak <- seq(1, seg_pars$S_pops, by = 1)
names(number_S_with_outbreak)<-c("number_S_with_outbreak")

size_initial_S_outbreak <- seq(1, 48, by = 1)
names(size_initial_S_outbreak) <- c("size_initial_S_outbreak")




epsilon <- seq(0, 0.5, length.out = num_values)
names(epsilon) <- c("epsilon")

delta <- seq(0, 1, length.out = num_values)
names(delta) <- c("delta")

gamma <- seq(0, 2*(sub_pop_sizes$C_internal/sub_pop_sizes$R_internal)*(2/24), length.out = num_values)
names(gamma) <- c("gamma")
}



# 4b) Create heatmap data frames ---------------------


results_gamma_delta <- heatmap(gamma, delta)
save(results_gamma_delta, file = "results_gamma_delta.RData")

results_epsilon_gamma <- heatmap(epsilon, gamma)
save(results_epsilon_gamma, file = "results_epsilon_gamma.RData")

results_epsilon_delta <- heatmap(epsilon, delta)
save(results_epsilon_delta, file = "results_epsilon_delta.RData")

# results_epsilon_beta_rr_end <- heatmap(epsilon, beta_rr_end)
# save(results_epsilon_beta_rr_end, file = "results_epsilon_beta_rr_end.RData")
# 
# # results_epsilon_beta_s_end <- heatmap(epsilon, beta_s_end)
# # save(results_epsilon_beta_s_end, file = "results_epsilon_beta_s_end.RData")
# 
# results_epsilon_beta_c_end <- heatmap(epsilon, beta_c_end)  
# save(results_epsilon_beta_c_end, file = "results_epsilon_beta_c_end.RData")
# 
# results_epsilon_beta_rr_rate <- heatmap(epsilon, beta_rr_rate)
# save(results_epsilon_beta_rr_rate, file = "results_epsilon_beta_rr_rate.RData")
# 
# # results_epsilon_beta_s_rate <- heatmap(epsilon, beta_s_rate)
# # save(results_epsilon_beta_s_rate, file = "results_epsilon_beta_s_rate.RData")
# 
# results_epsilon_beta_c_rate <- heatmap(epsilon, beta_c_rate)
# save(results_epsilon_beta_c_rate, file = "results_epsilon_beta_c_rate.RData")
# 
# results_epsilon_beta_c_low <- heatmap(epsilon, beta_c_low)
# save(results_epsilon_beta_c_low, file = "results_epsilon_beta_c_low.RData")
# 
# results_epsilon_beta_c_high <- heatmap(epsilon, beta_c_high)
# save(results_epsilon_beta_c_high, file = "results_epsilon_beta_c_high.RData")
# 
# results_epsilon_beta_s_high <- heatmap(epsilon, beta_s_high)
# save(results_epsilon_beta_s_high, file = "results_epsilon_beta_s_high.RData")
#
#
#
# 
# results_gamma_delta <- heatmap(gamma, delta)
# save(results_gamma_delta, file = "results_gamma_delta.RData")
# 
# results_gamma_beta_c_end <- heatmap(gamma, beta_c_end)
# save(results_gamma_beta_c_end, file = "results_gamma_beta_c_end.RData")
# 
# results_gamma_beta_s_end <- heatmap(gamma, beta_s_end)
# save(results_gamma_beta_s_end, file = "results_gamma_beta_s_end.RData")
# 
# results_gamma_beta_rr_end <- heatmap(gamma, beta_rr_end)
# save(results_gamma_beta_rr_end, file = "results_gamma_beta_rr_end.RData")
# 
# results_gamma_beta_rr_rate <- heatmap(gamma, beta_rr_rate)
# save(results_gamma_beta_rr_rate, file = "results_gamma_beta_rr_rate.RData")
# 
# results_gamma_beta_c_rate <- heatmap(gamma, beta_c_rate)
# save(results_gamma_beta_c_rate, file = "results_gamma_beta_c_rate.RData")
# 
# # results_gamma_beta_s_rate <- heatmap(gamma, beta_s_rate)
# # save(results_gamma_beta_c_rate, file = "results_gamma_beta_c_rate.RData")
# 
# 
# 
# results_delta_beta_c_end <- heatmap(delta, beta_c_end)
# save(results_delta_beta_c_end, file = "results_delta_beta_c_end.RData")
# 
# results_delta_beta_s_end <- heatmap(delta, beta_s_end)
# save(results_delta_beta_s_end, file = "results_delta_beta_s_end.RData")
# 
# results_delta_beta_rr_end <- heatmap(delta, beta_rr_end)
# save(results_delta_beta_rr_end, file = "results_delta_beta_rr_end.RData")
# 
# results_delta_beta_c_rate <- heatmap(delta, beta_c_rate)
# save(results_delta_beta_c_rate, file = "results_delta_beta_c_rate.RData")
# 
# # results_delta_beta_s_rate <- heatmap(delta, beta_s_rate)
# # save(results_delta_beta_s_rate, file = "results_delta_beta_s_rate.RData")
# 
# results_delta_beta_rr_rate <- heatmap(delta, beta_rr_rate)
# save(results_delta_beta_rr_rate, file = "results_delta_beta_rr_rate.RData")
# 
# 
# 
results_beta_rr_end_beta_c_end <- heatmap(beta_rr_end, beta_c_end)
save(results_beta_rr_end_beta_c_end, file = "results_beta_rr_end_beta_c_end.RData")
# 
# results_beta_rr_end_beta_s_end <- heatmap(beta_rr_end, beta_s_end)
# save(results_beta_rr_end_beta_s_end, file = "results_beta_rr_end_beta_s_end.RData")
# 
# results_beta_rr_end_beta_rr_rate <- heatmap(beta_rr_end, beta_rr_rate)
# save(results_beta_rr_end_beta_rr_rate, file = "results_beta_rr_end_beta_rr_rate.RData")
# 
# results_beta_rr_end_beta_c_rate <- heatmap(beta_rr_end, beta_c_rate)
# save(results_beta_rr_end_beta_c_rate, file = "results_beta_rr_end_beta_c_rate.RData")
# 
# results_beta_rr_end_beta_s_rate <- heatmap(beta_rr_end, beta_s_rate)
# save(results_beta_rr_end_beta_s_rate, file = "results_beta_rr_end_beta_s_rate.RData")
# 
# 
# 
# results_beta_s_end_beta_c_end <- heatmap(beta_s_end, beta_c_end)
# save(results_beta_s_end_beta_c_end, file = "results_beta_s_end_beta_c_end.RData")
#
# results_beta_s_end_beta_rr_rate <- heatmap(beta_s_end, beta_rr_rate)
# save(results_beta_s_end_beta_rr_rate, file = "results_beta_s_end_beta_rr_rate.RData")
#
# results_beta_s_end_beta_s_rate <- heatmap(beta_s_end, beta_s_rate)
# save(results_beta_s_end_beta_s_rate, file = "results_beta_s_end_beta_s_rate.RData")
#
# results_beta_s_end_beta_c_rate <- heatmap(beta_s_end, beta_c_rate)
# save(results_beta_s_end_beta_c_rate, file = "results_beta_s_end_beta_c_rate.RData")
# 
# 
# 
# 
# results_beta_c_end_beta_rr_rate <- heatmap(beta_c_end, beta_rr_rate)
# save(results_beta_c_end_beta_rr_rate, file = "results_beta_c_end_beta_rr_rate.RData")
# 
# results_beta_c_end_beta_s_rate <- heatmap(beta_c_end, beta_s_rate)
# save(results_beta_c_end_beta_s_rate, file = "results_beta_c_end_beta_s_rate.RData")
# 
# results_beta_c_end_beta_c_rate <- heatmap(beta_s_end, beta_c_rate)
# save(results_beta_c_end_beta_c_rate, file = "results_beta_s_end_beta_c_rate.RData")
# 
# 
# 
# results_beta_rr_rate_beta_s_rate <- heatmap(beta_rr_rate, beta_s_rate)
# save(results_beta_rr_rate_beta_s_rate, file = "results_beta_rr_rate_beta_s_rate.RData")
# 
# results_beta_rr_rate_beta_c_rate <- heatmap(beta_rr_rate, beta_c_rate)
# save(results_beta_rr_rate_beta_c_rate, file = "results_beta_rr_rate_beta_c_rate.RData")
# 
# 
# results_beta_s_rate_beta_c_rate <- heatmap(beta_s_rate, beta_c_rate)
# save(results_beta_s_rate_beta_c_rate, file = "results_beta_s_rate_beta_c_rate.RData")
# 
# 
# results_beta_rr_high_beta_c_high <- heatmap(beta_rr_high, beta_c_high)
# save(results_beta_rr_high_beta_c_high, file = "results_beta_rr_high_beta_c_high.RData")
# 
# results_initial_infected_R_total_beta_rr_end <- heatmap(initial_infected_R_total, beta_rr_end)
# save(results_initial_infected_R_total_beta_rr_end, file = "results_initial_infected_R_total_beta_rr_end.RData")
# 
# results_initial_infected_R_total_beta_c_end <- heatmap(initial_infected_R_total, beta_c_end)
# save(results_initial_infected_R_total_beta_c_end, file = "results_initial_infected_R_total_beta_c_end.RData")
# 
# results_initial_infected_R_total_gamma <- heatmap(initial_infected_R_total, gamma)
# save(results_initial_infected_R_total_gamma, file = "results_initial_infected_R_total_gamma.RData")
# 
# 
# results_gamma_beta_c_high <- heatmap(gamma, beta_c_high)
# save(results_gamma_beta_c_high, file = "results_gamma_beta_c_high.RData")
# 
# 


