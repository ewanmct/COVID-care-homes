# Code Description ############################################################
# Date: 09_08_2021
# Written by: Matthew Baister, Ewan McTaggart


# Sensitivity analysis of two parameters varied on % change in 
# final deaths and change in LSE 

# Load in the dataframes and plot

# To do this we'll make heatmaps/contour plots: x and y axis will be two 
# parameters, z axis final deaths/LSE

rm(list = ls())

# 1) Preamble - Source scripts with SEIRD functions, read in parameters from script 2_SEIRD
# 2) Functions for plotting and manipulating data
# 3) Load in and plot results


# 1) Preamble ----------------------------------------------------------

# if (!"plotly" %in% installed.packages())
#   install.packages("plotly")
#library(plotly)                  # A plotting library for making heatmaps. Plots are interactive. 

if (!"ggplot2" %in% installed.packages())
  install.packages("ggplot2")
library(ggplot2)

# if (!"parallel" %in% installed.packages())
#   install.packages("parallel")
library(parallel)               # Library with parallelised verisions of lapply etc. For calculating model output for different sets of parameters.

if (!"patchwork" %in% installed.packages())
  install.packages("patchwork")
library(patchwork)

if (!"metR" %in% installed.packages())
  install.packages("metR")
library(metR)

if (!"viridis" %in% installed.packages())
  install.packages("viridis")
library(viridis)


load("seeded_4home_E_best_fit.RData")

# import the SEIRD functions and baseline parameters from the R scripts:
source('2_SEIRD.R')

# Read in case and death data to calculate least squares against:
source('READ_DATA.R')



# 2) Functions  --------------

# Function to make plot from a data frame 

make_a_plot_from_data <- function(data, legend_name){
  
  x_label <-colnames(data)[1]
  y_label <-colnames(data)[2]
  
  the_plot <- ggplot(data, aes(data[,1],data[,2], z = data[,3], fill = data[,3]))  +
    geom_tile() +
    # geom_contour(colour = "black", bins = 10, size=0.5) +
    
    scale_fill_viridis(option = "A") +
  labs(title = ""
       ,subtitle = ""
       ,x = as.expression(bquote(.(as.name(x_label))))
       ,y = as.expression(bquote(.(as.name(y_label))))
       ,fill = legend_name
  ) +
    scale_x_continuous(expand=c(0,0)) +
    scale_y_continuous(expand=c(0,0)) +
    theme_bw() +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          #,legend.position = ""
          ,axis.title.y = element_text(angle = 0, size = 15, margin = margin(t = 0, r = 10, b = 0, l = 0), hjust = 0.5, vjust = 0.5)
          ,axis.title.x = element_text(size = 15, margin = margin(t = 10, r = 10, b = 0, l = 0))
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE,
      even.steps = FALSE,
      frame.linewidth = 0.6,
      frame.colour = "black",
      ticks.colour = "black",
      barheight = 17,
      #barwidth = 2,
      # title = "Least squares error (log)",
      ticks.linewidth = 0.6)
    )
  
  return(the_plot)
}


# If we only have the heatmap data...
# Say stored in a list called "results" as 4 data frames
# - Resident deaths
# - Staff deaths
# - Rest deaths
# - Least squares error

# Then this function will make all the plots...



make_all_plots <- function(results){

  # function to make plot for one set of data is
  # make_plot_from_data(data, legend_name)

  # legends corresponding to each set of data
  legend_names <- as.list(c("Resident deaths", "Staff deaths", "Rest deaths", "Least squares error"))

  # combine the legend names and the data frames (results) into one list

  list_for_function <- Map(list, results, legend_names)

  all_plots_storage <- lapply(list_for_function, function(x){make_a_plot_from_data(x[[1]],x[[2]])})

  names(all_plots_storage) <- legend_names

  return(all_plots_storage)

}




# 3) Load in heatmaps and look at results -------------

load("results_beta_rr_end_beta_c_end.RData")

# if looking only at beta c end times larger than 37
results_beta_rr_end_beta_c_end[5:8] <- lapply(results_beta_rr_end_beta_c_end[5:8], subset_end_times)

# to log LS error
results_beta_rr_end_beta_c_end[[8]][,3]<-log(results_beta_rr_end_beta_c_end[[8]][,3])


results_beta_rr_end_beta_c_end_plot<-make_all_plots(results_beta_rr_end_beta_c_end[5:8])
beta_rr_end_beta_c_end_LS_plot <- results_beta_rr_end_beta_c_end_plot$`Least squares error` +
  labs(title = ""
       ,subtitle = ""
       ,x = as.expression(bquote(omega[end]^G))
       ,y = as.expression(bquote(omega[end]^C))
  ) +
  guides(fill = guide_colorbar(
    ticks = TRUE,
    even.steps = FALSE,
    frame.linewidth = 0.6,
    frame.colour = "black",
    ticks.colour = "black",
    barheight = 18,
    #barwidth = 2,
    title = "Aggregated sum of \nsquares error (log)",
    ticks.linewidth = 0.6)
  )

ggsave(plot = beta_rr_end_beta_c_end_LS_plot, filename = "beta_rr_end_beta_c_end_LS_plot.png"
       ,units = "mm", width=186, height = 135)
