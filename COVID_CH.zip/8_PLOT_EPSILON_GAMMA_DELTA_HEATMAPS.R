# Code Description ############################################################
# Date: 09_08_2021
# Written by: Matthew Baister, Ewan McTaggart


# Sensitivity analysis of two parameters varied on change in 
# final deaths. To do this we'll make heatmaps/contour plots:
# x and y axis will be two parameters, z axis final deaths

# This script loads in the dataframes and plots them

rm(list = ls())

# 1) Preamble - Source scripts with SEIRD functions, read in parameters from script 2_SEIRD
# 2) Functions for plotting and manipulating data
# 3) Load in and inspect results


# 1) Preamble ----------------------------------------------------------

# if (!"plotly" %in% installed.packages())
#   install.packages("plotly")
#library(plotly)                  # A plotting library for making heatmaps. Plots are interactive. 

if (!"ggplot2" %in% installed.packages())
  install.packages("ggplot2")
library(ggplot2)

# if (!"parallel" %in% installed.packages())
#   install.packages("parallel")
library(parallel)               # Library with parallelised verisions of lapply etc. For calculating model output for different sets of parameters.

if (!"patchwork" %in% installed.packages())
  install.packages("patchwork")
library(patchwork)

if (!"metR" %in% installed.packages())
  install.packages("metR")
library(metR)

if (!"viridis" %in% installed.packages())
  install.packages("viridis")
library(viridis)


load("seeded_4home_E_best_fit.RData")

# import the SEIRD functions and baseline parameters from the R scripts:
source('2_SEIRD.R')


# 2) Functions ---------------


# Function to fix gamma ticks for interprebility

# First need this

sub_pop_sizes <- list(    # internal subpopulation sizes 
  
  C_internal = 48,                         # population of a single CH
  S_internal = 48,                         # population of a single staff population # = C_internal (assuming 1:1 resident:staff member ratio per home)
  R_internal = 907580-2*48*109 # population of a single rest population # (assuming CH resident population is 0.57-0.6% of population)
)

# then

fix_gamma_ticks <- function(x){
  
  # We change the ticks on the heatmap by changing the dataframe
  
  # gamma values are in the form of the proportion of R population mixing at CH's 
  # each day. This function converts those values to the proportion of the 
  # visitors day spent at care home home.
  
  x[,"gamma"]<-x[,"gamma"]*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal
  
  return(x)
  
}


 
# Function to make plot from a data frame 

make_a_plot_from_data <- function(data, legend_name){
  
  x_label <-colnames(data)[1]
  y_label <-colnames(data)[2]
  
  the_plot <- ggplot(data, aes(data[,1],data[,2], z = data[,3], fill = data[,3]))  +
    geom_tile() +
    geom_contour(colour = "black", bins = 15, size=0.5) +
    scale_fill_viridis(option = "A"
                       ,limits = c(47,490)
                       ,breaks = c(47,seq(100,450,50),490)
                       ,labels = c(47,seq(100,450,50),490)
                       ,na.value = "black"
    ) +
  labs(title = ""
       ,subtitle = ""
       ,x = as.expression(bquote(.(as.name(x_label))))
       ,y = as.expression(bquote(.(as.name(y_label))))
       ,fill = "Resident\ndeaths"
  ) +
    scale_x_continuous(expand=c(0,0)) +
    scale_y_continuous(expand=c(0,0)) +
    theme_bw() +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,legend.title=element_text(size=20)
          ,legend.text = element_text(size=14)
          #,legend.position = ""
          ,axis.title.y = element_text(angle = 0, size = 23, margin = margin(t = 0, r = 10, b = 0, l = 0), hjust = 0.5, vjust = 0.5)
          ,axis.title.x = element_text(size = 23, margin = margin(t = 10, r = 10, b = 0, l = 0))
          ,axis.text = element_text(size = 14)
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE,
      even.steps = FALSE,
      frame.linewidth = 0.6,
      frame.colour = "black",
      ticks.colour = "black",
      barheight = 15,
      barwidth = 2.5,
      ticks.linewidth = 0.6)
    )
  
  
  return(the_plot)
}



# We only have the heatmap data...
# Say stored in a list called "results" as 4 data frames
# - Resident deaths
# - Staff deaths
# - Rest deaths
# - Least squares error

# Then this function will make all the plots...

make_all_plots <- function(results){
  
  # function to make plot for one set of data is
  # make_plot_from_data(data, legend_name)
  
  # legends corresponding to each set of data
  legend_names <- as.list(c("Resident deaths", "Staff deaths", "Rest deaths", "Least squares error"))
  
  # combine the legend names and the data frames (results) into one list
  
  list_for_function <- Map(list, results, legend_names)
  
  all_plots_storage <- lapply(list_for_function, function(x){make_a_plot_from_data(x[[1]],x[[2]])})
  
  names(all_plots_storage) <- legend_names
  
  return(all_plots_storage)
  
}





# 3) Inspect epsilon , delta, gamma results --------------

load("results_epsilon_delta.RData")
load("results_epsilon_gamma.RData")
load("results_gamma_delta.RData")

z_limits <- c(min(min(results_epsilon_delta[[5]][,3]), min(results_epsilon_gamma[[5]][,3]), min(results_gamma_delta[[5]][,3])),
  max(results_epsilon_delta[[5]][,3], results_epsilon_gamma[[5]][,3], results_gamma_delta[[5]][,3])
)

load("results_epsilon_delta.RData")
results_epsilon_delta_plots<-make_all_plots(results_epsilon_delta[5:8])

# results_epsilon_delta$`Resident deaths data`

load("results_epsilon_gamma.RData")
results_epsilon_gamma[5:8] <- lapply(results_epsilon_gamma[5:8], fix_gamma_ticks)
results_epsilon_gamma_plots <- make_all_plots(results_epsilon_gamma[5:8])

load("results_gamma_delta.RData")
results_gamma_delta[5:8] <- lapply(results_gamma_delta[5:8], fix_gamma_ticks)
results_gamma_delta_plots<-make_all_plots(results_gamma_delta[5:8])





# arrange plots

epsilon_delta_plot <- results_epsilon_delta_plots$`Resident deaths` +
  #geom_point( x = as.numeric(seeded_4home_E_best_fit$Optimal_epsilon), y = as.numeric(seeded_4home_E_best_fit$Optimal_delta), size = 3, shape = 16, colour = 'black') +
  geom_point( x = as.numeric(seeded_4home_E_best_fit$Optimal_epsilon), y = as.numeric(seeded_4home_E_best_fit$Optimal_delta), size = 4, shape = 3, colour = 'black')


epsilon_gamma_plot <- results_epsilon_gamma_plots$`Resident deaths` +
  #geom_point( x = as.numeric(seeded_4home_E_best_fit$Optimal_epsilon), y = as.numeric(seeded_4home_E_best_fit$Optimal_gamma*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal), size = 3, shape = 16, colour = 'black') +
  geom_point( x = as.numeric(seeded_4home_E_best_fit$Optimal_epsilon), y = as.numeric(seeded_4home_E_best_fit$Optimal_gamma*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal), size = 4, shape = 3, colour = 'black') +
  labs(y = expression(omega[high]^gamma))

gamma_delta_plot <- results_gamma_delta_plots$`Resident deaths` +
  #geom_point( x = as.numeric(seeded_4home_E_best_fit$Optimal_gamma*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal), y = as.numeric(seeded_4home_E_best_fit$Optimal_delta), size = 3, shape = 16, colour = 'black') +
  geom_point( x = as.numeric(seeded_4home_E_best_fit$Optimal_gamma*sub_pop_sizes$R_internal/sub_pop_sizes$C_internal), y = as.numeric(seeded_4home_E_best_fit$Optimal_delta), size = 4, shape = 3, colour = 'black') +
  labs(x = expression(omega[high]^gamma))


# epsilon_gamma_delta_plots <- epsilon_delta_plot + epsilon_gamma_plot + gamma_delta_plot + plot_layout(guides = "collect")
# ggsave(plot = epsilon_gamma_delta_plots, filename = "epsilon_gamma_delta_plots_tiles_contours.png"
#        ,units = "mm", width=420, height = 140)

epsilon_gamma_delta_plots <- epsilon_delta_plot + labs(tag="(a)") + epsilon_gamma_plot +labs(tag="(b)")+ gamma_delta_plot +labs(tag="(c)")+ plot_layout(guides = "collect") & theme(plot.tag = element_text(size = 20))
ggsave(plot = epsilon_gamma_delta_plots, filename = "epsilon_gamma_delta_plots_tiles_contours_tag.png"
       ,units = "mm", width=420, height = 140)



