# Code Description ############################################################
# Date: 09_08_2021
# Written by: Matthew Baister, Ewan McTaggart


# This script is to make data for barplots (tornado plots) showing sensitivity of model to its parameters.
#
# All parameters are first set to their fitted/base case values for 4 homes seeded. 
# We perturb individual parameters and measure the change in each populations 
# deaths. These results will then be visualised as a barplot.

# 1) Preamble - Source scripts with SEIRD functions, read in parameters from script 2_SEIRD
# 2) Listed here are the parameters we test the sensitivity of (see baseline vector)
# 3) Wrapper which calculates model solution for a given set of parameters and returns final number of deaths (C, S, R)
# 4) Make data, looking at what changing each parameter individually by a fixed value does to final number of deaths (C, S, R). 
# 


# 1) Preamble ----------------------------------------------------------

# if (!"plotly" %in% installed.packages())
#   install.packages("plotly")
#library(plotly)                  # A plotting library for making heatmaps. Plots are interactive. 

# if (!"ggplot2" %in% installed.packages())
#   install.packages("ggplot2")
library(ggplot2)

# if (!"parallel" %in% installed.packages())
#   install.packages("parallel")
library(parallel)               # Library with parallelised verisions of lapply etc. For calculating model output for different sets of parameters.

# if (!"patchwork" %in% installed.packages())
#   install.packages("patchwork")
library(patchwork)


# import the SEIRD functions and baseline parameters from the R scripts:
source('2_SEIRD.R')


# 2) Parameters to vary in sensitivity analysis ---------------------

baseline_names<-c("beta_rr_high"
                  ,"beta_rr_low"
                  ,"beta_rr_rate"
                  ,"beta_rr_end"
                  ,"beta_c_high"
                  ,"beta_c_low"
                  ,"beta_c_rate"
                  ,"beta_c_end"
                  ,"delta"
                  ,"epsilon"
                  ,"gamma"
                  ,"initial_infected_R_total"
                  ,"latency"
                  ,"tau")


# Load in fitted parameter values for the baseline vector

load("seeded_4home_E_best_fit.RData")
seeded_xhome_best_fit <- seeded_4home_E_best_fit

# Number of homes seeded we could consider  (further in code we fix this to only look at 4 homes seeded)
pops <- 1:10 


# Set up a place to store the barplot data

C <- matrix(nrow = length(pops), ncol = length(baseline_names))  # row will be % change in C final deaths, columns are different parameters
S <- matrix(nrow = length(pops), ncol = length(baseline_names))  # same but S final deaths
R <- matrix(nrow = length(pops), ncol = length(baseline_names))  # same but R final deaths

colnames(C) <- baseline_names
colnames(S) <- baseline_names
colnames(R) <- baseline_names

final_deaths_change_storage_C_varied <- list(increase_by_shift = list("C" = C, "S" = S, "R" = R)
                                             ,decrease_by_shift = list("C" = C, "S" = S, "R" = R)
)




for(j in 4){    
  
  # Note that this loop would allow you to change the homes seeded, then each parameter, and measure 
  # the change in deaths this causes in comparison to 4 homes seeded base case parameter values. You 
  # could incorporatw this by looping over more values for j.
  
  # However, as this loop only considers j at four homes seeded, the seeding does not change.
  # Thus we get the change in deaths of shifting individual parameters inside the 4 homes 
  # seeded base.
  
  num_homes_infected <- pops[j]
  num_S_infected <- 0
  
  baseline<-c(     # create vector of baseline parameter values
    
    # beta_rr high
    as.numeric(seeded_xhome_best_fit$All_params["R.Rt.High"])
    
    # beta_rr low
    ,baseRLow_pars$beta_rr
    
    # beta_rr rate
    ,as.numeric(seeded_xhome_best_fit$All_params["R.Rt.Rate"])
    
    # beta_rr end
    ,as.numeric(seeded_xhome_best_fit$All_params["R.Rt.End"])
    
    # beta_c high
    ,as.numeric(seeded_xhome_best_fit$All_params["CH.Rt.High"])
    
    # beta_c low
    ,as.numeric(seeded_xhome_best_fit$All_params["CH.Rt.Low"])
    
    # beta_c rate
    ,as.numeric(seeded_xhome_best_fit$All_params["CH.Rt.Rate"])
    
    # beta_c end
    ,as.numeric(seeded_xhome_best_fit$All_params["CH.Rt.End"])
    
    # delta
    ,as.numeric(seeded_xhome_best_fit$All_params["delta.vals"])
    
    # epsilon
    ,as.numeric(seeded_xhome_best_fit$All_params["epsilon.vals"])
    
    # gamma
    ,as.numeric(seeded_xhome_best_fit$All_params["gamma.vals"])
    
    # initial infected R total
    ,as.numeric(seeded_xhome_best_fit$All_params["initial.R.Inf"])
    
    # latency
    ,parms_passed$latency
    
    # tau
    ,parms_passed$Tau
  )
  names(baseline)<-baseline_names
  
  
  
  # 3) Function that generates a single output of sensitivity analysis -------------
  
  
  sensitivity_death_output <-  function(row_parameter_values, parms_passed){        
    
    # Function which takes a (named) vector of parameter values, 
    # then for each population (C, S, R) calculates;
    
    # - the final number of deaths by the end of the simulation (after 102 time steps)
    
    # The result is returned in vector form like this 
    # c(C_total, S_total, R_total)
    
    
    # The function replaces any items ran in 2_SEIRD which involve
    # the parameters being varied
    
    # Replace old parameter values with new values
    # from row_parameter_values:
    
    
    baseRHigh_pars <- list(
      
      beta_c = row_parameter_values["beta_c_high"], # internal Care home reproduction number
      beta_cc = row_parameter_values["beta_c_high"],  # between Care home reproduction number
      
      beta_cs = row_parameter_values["beta_c_high"], # Care home to Shielder/Staff reproduction number
      beta_sc = row_parameter_values["beta_c_high"], # Staff to Care home reproduction number (assume equal to beta_cs)
      
      
      # Remaining Shielder/Staff transmission rates 
      
      beta_s = (row_parameter_values["beta_c_high"]+row_parameter_values["beta_rr_high"])/2,   # internal Staff reproduction number
      beta_ss = (row_parameter_values["beta_c_high"]+row_parameter_values["beta_rr_high"])/2,  # between Staff reproduction number (could be higher than beta_rr due to mixing in workplace?)
      
      # Remaining Rest of Population transmission rates 
      beta_rr = row_parameter_values["beta_rr_high"] # rest of population to rest of population reproduction number    #4.56 is latency = 5.8 instead of 8
    )
    
    baseRLow_pars <- list(
      
      beta_c  = row_parameter_values["beta_c_low"], # internal Care home reproduction number
      beta_cc = row_parameter_values["beta_c_low"],  # between Care home reproduction number
      
      beta_cs = row_parameter_values["beta_c_low"],  # Care home to Shielder/Staff treproduction number
      beta_sc = row_parameter_values["beta_c_low"], # Staff to Care home reproduction number (assume equal to beta_cs)
      
      # Remaining Shielder/Staff reproduction number
      
      beta_s = (row_parameter_values["beta_c_low"]+row_parameter_values["beta_rr_low"])/2, # internal Staff reproduction number
      beta_ss = (row_parameter_values["beta_c_low"]+row_parameter_values["beta_rr_low"])/2, # between Staff reproduction number (could be higher than beta_rr due to mixing in workplace?)
      
      # Remaining Rest of Population reproduction numbers
      beta_rr = row_parameter_values["beta_rr_low"] # rest of population to rest of population reproduction number    #0.7 if latency = 5.8 instead of 8
    )
    
    
    baseEnd_pars <- list(
      
      c = row_parameter_values["beta_c_end"],   # internal Care home logi function end time
      cc = row_parameter_values["beta_c_end"],  # between Care home logi function end time
      cs = row_parameter_values["beta_c_end"],  # Care home to Shielder/Staff logi function end time
      sc = row_parameter_values["beta_c_end"],  # Staff to Care home logi function end time
      
      # Remaining Shielder/Staff logi function end times
      
      s = row_parameter_values["beta_c_end"],   # internal Staff logi function end time
      ss = row_parameter_values["beta_c_end"],  # between Staff logi function end time
      
      # # Note - Staff to rest of population logi function end time = rr
      rr = row_parameter_values["beta_rr_end"]   # rest of population to rest of population logi function end time
    )
    
    
    baseRate_pars <- list(
      
      c = row_parameter_values["beta_c_rate"],  # internal Care home logi function rate value
      cc = row_parameter_values["beta_c_rate"], # between Care home logi function rate value
      cs = row_parameter_values["beta_c_rate"], # Care home to Shielder/Staff logi function rate value
      sc = row_parameter_values["beta_c_rate"], # Staff to Care home logi function rate value
      
      # Remaining Shielder/Staff logi function rate value
      
      s = row_parameter_values["beta_c_rate"],  # internal Staff logi function rate value
      ss = row_parameter_values["beta_c_rate"], # between Staff logi function rate value
      rr = row_parameter_values["beta_rr_rate"]  # rest of population to rest of population logi function rate value
    )
    
    # num_homes_infected <- ... # don't need to set this as from running 2_SEIRD "num_homes_infected" is in the environment
    
    # num_S_infected <- ... # same logic
    
    Infect_init <- list(     # initial infected parameters
      
      # The initial total infected (reported + unreported, or symptomatic + asymptomatic)
      # in each subpopulation (e.g. R_total_infected) is split evenly between the 
      # subpopulations in that population that have an initial outbreak (e.g. R_subs_inf).
      
      C_subs_inf = C_initial_dist(seg_pars, num_homes_infected),  # C subpopulations that all initial C cases (C_total_infected) is split evenly between. Length must be less than or equal to seg_pars$C_pops. If no subpopulations have outbreak set as NULL.
      S_subs_inf = C_initial_dist(seg_pars, num_S_infected),  # S subpopulations that all initial S cases (S_total_infected) is split evenly between. Length must be less than or equal to seg_pars$S_pops. If no subpopulations have outbreak set as NULL.
      R_subs_inf = c(1),                   # R subpopulations that all initial R cases (R_total_infected) is split evenly between. Length must be less than or equal to seg_pars$R_pops. If no subpopulations have outbreak set as NULL.
      
      C_total_infected = num_homes_infected/(1-asymptomatic_proportions$C_asymp),  # i.e. assuming 1 symptomatic case in "num_homes_infected" homes                  # total initial infected across all care home sub-populations
      S_total_infected = num_S_infected/(1-asymptomatic_proportions$S_asymp),                     # total initial infected across all staff sub-populations
      R_total_infected = row_parameter_values["initial_infected_R_total"]       # total initial infected across all rest sub-populations
      
      # Note: this requires (initial total infected + initital total exposed)/(number subpopulations with initial outbreak) = total infected or exposed in subpopulation initially < = capacity of that subpopulation
      #       for every subpopulation of C, S and R.
      
    )
    
    parms_passed$Travel_pars <- list(    
      # Parameters used to create the travel matrix, T. 
      # This is the matrix whose [i,j] element is the
      # the proportion of subpopulation i who travel to j
      
      # To create this matrix these get passed into create_TravelMatrix
      
      # note that these proportions are "averaged out over a whole day"
      
      delta = row_parameter_values["delta"],            # Proportion of staff who are at CH's instead of mixing with Rest. Controls how many staff are at each CH on average.
      # epsilon =           # Proportion of a CH's staff who work at other homes
      # gamma =             # Proportion of Rest that visit each CH. Total proportion who visit is seg_pars$C_pops*gamma. General form of gamma = x(sub_pop_sizes$C_internal/sub_pop_sizes$R_internal)(y), where x is the number of visitors per day per resident, and y is the proportion of a day a visitor spends at a care home
      
      # epsilon and gamma are time dependent (we model each of their trajectories using the logi function)
      # .....
      epsilon_pars =  list(start = -82,
                           end = row_parameter_values["beta_rr_end"],
                           rate =  row_parameter_values["beta_rr_rate"], 
                           low = row_parameter_values["epsilon"], 
                           high = row_parameter_values["epsilon"]),
      
      gamma_pars =  list(start = -82,        # gamma is the proportion of Rest that visit each CH. Total proportion who visit is seg_pars$C_pops*gamma. General form of gamma = x(sub_pop_sizes$C_internal/sub_pop_sizes$R_internal)(y), where x is the number of visitors per day per resident, and y is the proportion of a day a visitor spends at a care home
                         end = 10,
                         rate = 3,
                         low = 0,
                         high = row_parameter_values["gamma"])
      
      # community.size = 2                            # Total number of homes some proportion of a CH's staff work at (including "their" home)
    )
    
    
    
    
    
    # replace parameter lists/matrices that get passed to functions ---
    
    # generate initial SEIRD values per sub-population as a vector
    SEIRD_vectors <- create_SEIRDVector(seg_pars, sub_pop_sizes, Infect_init, asymptomatic_proportions)
    
    ## FIRST WAVE matrices ##
    
    # Create matrix of baseRLow values
    parms_passed$baseRLow_matrix <- create_RMatrix(baseRLow_pars,seg_pars,between_pars)
    
    # create matrix of baseRHigh Values
    parms_passed$baseRHigh_matrix <- create_RMatrix(baseRHigh_pars, seg_pars,between_pars)
    
    # create matrix of baseEnd values
    parms_passed$baseEnd_matrix <- create_WaveMatrix(baseEnd_pars, seg_pars)
    
    # create matrix of baseRate values
    parms_passed$baseRate_matrix <- create_WaveMatrix(baseRate_pars, seg_pars)
    
    
    
    ## OTHER parameter lists ##
    
    parms_passed$latency <- row_parameter_values["latency"]
    parms_passed$Tau <- row_parameter_values["tau"]
    
    
    # Next calculate the model solution... 
    # (note that only need the start and end times if calculating final deaths)
    
    # Run sim
    sims_multi_logi <- ode(y = SEIRD_vectors, times = simTime, func = seird_multi_logi, parms = parms_passed)
    
    # array holds SEIRD values, e.g., S_c = Carehome_values[,,1], E_c = Carehome_values[,,2], etc.
    Carehome_values <- careHome_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
    
    # array holds SEIRD values, e.g., S_s = Shielder_values[,,1], E_s = Shielder_values[,,2], etc.
    Shielder_values <- Shielder_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
    
    # array holds SEIRD values, e.g., S_R = Shielder_values[,,1], E_R = Shielder_values[,,2], etc.
    Rest_values <- Rest_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
    
    
    # Now calculate the total number of deaths at the end of the simulation 
    
    
    # CH population
    C_total<-rowSums(Carehome_values[,,6])[length(rowSums(Carehome_values[,,6]))]
    
    # Staff population
    S_total<-rowSums(Shielder_values[,,6])[length(rowSums(Shielder_values[,,6]))]
    
    # Rest population
    R_total<-Rest_values[,,6][length(Rest_values[,,6])]
    
    return(list("C" = C_total, "S" = S_total, "R" = R_total)) 
    
    # returns a vector, where each element is the final deaths for C, S, and R respectively
    
  }
  
  
  
  # 4) -shift, central, + shift analysis   ----------------------------------------
  
  # Take each parameter in 2), and calculate the final number of deaths
  # in each population (C, S, R), for;
  #   - the baseline value of that parameter (central value)
  #   - that parameter decreased by "shift"
  #   - that parameter increased by "shift"
  
  # Then plot the results for every parameter as a barplot
  
  # First define the shift (increase/decrease) for each parameter
  
  shift <- vector(length = length(baseline_names))
  names(shift) <- baseline_names
  
  shift["beta_rr_high"]<-0.1
  shift["beta_rr_low"]<-0.1
  shift["beta_rr_rate"]<-0.1
  shift["beta_rr_end"]<-1
  
  shift["beta_c_high"]<-0.1     # 0.2 if estimated range is 2, 0.1 if estimated range is 1 
  shift["beta_c_low"]<-0.1
  shift["beta_c_rate"]<-0.1
  shift["beta_c_end"]<-1
  
  shift["delta"]<-0.1
  shift["epsilon"]<-0.05
  shift["gamma"]<-0.1*2*(sub_pop_sizes$C_internal/sub_pop_sizes$R_internal)*(2/24)
  shift["initial_infected_R_total"]<-10
  shift["latency"]<-0.3
  shift["tau"]<-0.4
  
  
  # Then create matrices where each row is a vector of the parameter values
  # in baseline, but one parameter has changed
  
  
  # Changing each parameter from baseline by - shitf
  
  minus_shift_matrix <- matrix(rep(baseline,length(baseline)), byrow = T,
                                    nrow = length(baseline), ncol =length(baseline))
  diag(minus_shift_matrix) <- diag(minus_shift_matrix) - shift
  colnames(minus_shift_matrix) <- baseline_names
  
  
  
  
  # Changing each parameter from baseline by + shift
  
  plus_shift_matrix <- matrix(rep(baseline,length(baseline)), byrow = T,
                                   nrow = length(baseline), ncol =length(baseline))
  diag(plus_shift_matrix) <- diag(plus_shift_matrix) + shift
  
  colnames(plus_shift_matrix) <- baseline_names
  shift_matrix<-rbind(minus_shift_matrix, plus_shift_matrix)
  
  
  # convert shift_matrix to a list of rows
  # (this is so we can use lappply to apply the function sensitivity_death_output to
  # each row of shift_matrix)
  
  shift_list <- as.list(as.data.frame(t(shift_matrix)))  # a list where each element is a row of shift_matrix
  
  # the below takes shift_list and adds the parameter names above each parameter
  shift_list <- lapply(1:nrow(shift_matrix)
                             ,function(x){ names(shift_list[[x]]) <- colnames(shift_matrix)
                             return(shift_list[[x]]) })
  
  
  # apply the function sensitivity_death_output to each element of shift_list (row of shift_matrix)
  
  # for parallel calculations...
  
  # number of cores ----
  no_cores <- 28

  # Initiate cluster
  cl <- makeCluster(no_cores, type = "FORK")


  multiple_parameter_output<-parLapply(cl, shift_list,
                                       function(dummy_shift_list){sensitivity_death_output(dummy_shift_list
                                                                                        ,parms_passed)}
  )

  # stop cluster
  stopCluster(cl)
  
  
  
  # # if not using parallel computations...
  # multiple_parameter_output <- lapply(shift_list,
  #                                     function(dummy_shift_list){sensitivity_death_output(dummy_shift_list
  #                                                           ,parms_passed)}
  # )
  
  
  # convert lapply output from list of rows to matrix
  final_deaths<-matrix(unlist(multiple_parameter_output), ncol=3, byrow=T)
  colnames(final_deaths)<-c("C","S","R")
  
  
  # also calculate the final deaths in each population for baseline parameters
  baseline_deaths<-sensitivity_death_output(baseline, parms_passed)
  baseline_deaths<-matrix(unlist(baseline_deaths), ncol=3, byrow=T)
  #save(baseline_deaths, file = "baseline_deaths")
  
  # change in final deaths relative to baseline
  final_deaths_change <- final_deaths-matrix(rep(baseline_deaths,nrow(shift_matrix)), ncol=3, byrow=T)
  
  # convert from absolute change to percentage change
  final_deaths_change[,1]<-(final_deaths_change[,1]/baseline_deaths[1,1])*100    # C final deaths change
  final_deaths_change[,2]<-(final_deaths_change[,2]/baseline_deaths[1,2])*100    # S final deaths change
  final_deaths_change[,3]<-(final_deaths_change[,3]/baseline_deaths[1,3])*100    # R final deaths change
  
  
  # Store the results
  
  # # structure of place to store barplot data is as follows
  # C <- matrix(ncol = length(baseline_names))  # row in this data frame will be % change in C final deaths, columns are different parameters
  # S <- matrix(ncol = length(baseline_names))  # same but S final deaths
  # R <- matrix(ncol = length(baseline_names))  # same but R final deaths
  # 
  # colnames(C) <- baseline_names
  # colnames(S) <- baseline_names
  # colnames(R) <- baseline_names
  # 
  # final_deaths_change_storage_C_varied <- list(increase_by_shift = list("C" = C, "S" = S, "R" = R)
  #                                     ,decrease_by_shift = list("C" = C, "S" = S, "R" = R)
  # )
  
  final_deaths_change_storage_C_varied$decrease_by_shift$C[j,] <- final_deaths_change[1:length(baseline),1] 
  final_deaths_change_storage_C_varied$decrease_by_shift$S[j,] <- final_deaths_change[1:length(baseline),2]
  final_deaths_change_storage_C_varied$decrease_by_shift$R[j,] <- final_deaths_change[1:length(baseline),3]
  
  final_deaths_change_storage_C_varied$increase_by_shift$C[j,] <- final_deaths_change[(length(baseline)+1):(2*length(baseline)),1]
  final_deaths_change_storage_C_varied$increase_by_shift$S[j,] <- final_deaths_change[(length(baseline)+1):(2*length(baseline)),2]
  final_deaths_change_storage_C_varied$increase_by_shift$R[j,] <- final_deaths_change[(length(baseline)+1):(2*length(baseline)),3]
  
  
}



final_deaths_change_storage_C_seeding_varied<-final_deaths_change_storage_C_varied

save(final_deaths_change_storage_C_seeding_varied, file = "final_deaths_change_storage_C_seeding_varied.RData")








