# Code Description ############################################################
# Date: 09_08_2021
# Written by: Matthew Baister, Ewan McTaggart


# This is a script to fit the model to data. We fix the number of homes seeded, and
# the script simulates over (solves the ode system) for a given list of permutations of
# the unfixed parameters (see manuscript for fixed parameters and assumptions). This script 
# makes use of a HPC's (in our case, ARCHIE-WeSt www.archie-west.ac.uk) 
# speed (more cores) to solve the system for thousands of different scenarios in parallel. 
# These scenarios are ranked by measuring the aggregated sum of squares error of the model 
# output against the data (in code called least squares errors). The best ranking will give the
# model parameters that fit the data best.

# This script performs this fitting process for "number of homes seeded" fixed at 4. To run
# the fitting for a different number of homes seeded change line 74


# 1) Preamble - Source any script with SEIRD functions, read in data
# 2) Generate matrix of scenarios
# 3) Wrapper which returns model output and the least squares error for each scenario
# 4) Calculate model output and the least squares error for all scenarios (parrallelised)
# 5) Find most accurate (in terms of how the model output fits data) scenarios
# 6) Save the data (all least squares errors for all scenarios) 
# 7) Save extra data for the best fitting scenario for the fixed number of homes seeded (say 4)



# 1) Preamble ----------------------------------------------------------

# set working directory

# working.directory <- 
# setwd(working.directory)

# load in packages

# if (!"tidyr" %in% installed.packages()){
#   install.packages("tidyr")}
library("tidyr")
# 
# if (!"zoo" %in% installed.packages()){
#   install.packages("zoo")}
library("zoo")
# 
# if (!"readxl" %in% installed.packages()){
#   install.packages("readxl")}
# library("readxl")
# 
# if (!"parallel" %in% installed.packages()){
#   install.packages("parallel")}
library("parallel")



# import the SEIRD functions and baseline parameters from the R scripts:

source('2_SEIRD.R')   # note that only need to run up to ode calculation

# Read in case and death data to calculate least squares against:

source('READ_DATA.R')


# 2) Scenario matrix (scenario_matrix) ------------------

# We first define ranges for the parameters we are interested in. Then
# we generate a matrix of all possible permutations of these parameters.
# Each row of this matrix represents a different scenario


# total initial infected general population
initial.R.Inf <- seq(100, 180, by = 10)

# number CHs seeded with an initial outbreak (assuming 1 symptomatic case in each)
number.CHs.with.outbreak <- c(4)

delta.vals <- c(0.5)
# delta.vals <- c(0.5)


epsilon.vals <- seq(0.1, 0.5, by = 0.1) 
# epsilon.vals <- 0.1

# visitation
gamma.vals <- c(1,2,4)*(sub_pop_sizes$C_internal/sub_pop_sizes$R_internal)*(1/24)                                
                               
CH.Rt.High <- seq(3.3, 5, by = 0.1)


CH.Rt.Low <- 0.6

CH.Rt.End <- c(42)  

CH.Rt.Rate <- c(0.5)

R.Rt.Rate <- c(0.5)

R.Rt.High <- seq(3.3, 4.5, by = 0.1)

R.Rt.End <- c(18+4)


# Now determine all possible permutations of these parameters being varied
scenario_matrix <- as.matrix(crossing(initial.R.Inf, number.CHs.with.outbreak, delta.vals, epsilon.vals, gamma.vals, CH.Rt.High, CH.Rt.Low, CH.Rt.End, CH.Rt.Rate,
                                      R.Rt.Rate, R.Rt.High, R.Rt.End))

scenario_matrix<-scenario_matrix[scenario_matrix[,'CH.Rt.High'] >= scenario_matrix[,'R.Rt.High'] ,]

save(scenario_matrix, file = "scenario_matrix.RData")
# no. of scenarios = nrow(scenario_matrix)


# 3) Wrapper returning model solution for a given scenario ---------------

# A row of the scenario_matrix is passed into the wrapper, and the output will be:
# i) the model solution (i.e. script 2_SEIRD)
# and ii) the aggregated sum of squares error / least squares error of the solution 
# compared to data


# This function replaces some of the parameters in script 2_SEIRD with a scenario from the matrix of scenarios

# IMPORTANT: this wrapper requires first running script 2_SEIRD to get the baseline parameters

model_output <-  function(scenario       # note that scenario is a row vector of parameters to change. It will be a row of the scenario_matrix     
                          ,simTime            # these other parameters passed as arguments are stored in the environment after running script 2_SEIRD
                          ,seg_pars
                          ,sub_pop_sizes
                          ,between_pars
                          ,asymptomatic_proportions
                          ,parms_passed
                          ,Date.sim
                          ,Lothian
                          ,Weekly_Deaths_Lothian
                          ,daily.carehome.case.count
                          ,death.count.weeks
                          ,C.H.weekly.death.count){ 
  
  
  # Now we replace the parameter lists/matrices in script 2_SEIRD that are varied
  
  #
   
  #
  
  #
  
  baseRHigh_pars <- list(
    
    beta_c = scenario["CH.Rt.High"],   # internal Care home reproduction number
    beta_cc = 0,                       # between Care home reproduction number
    
    beta_cs = scenario["CH.Rt.High"],  # Care home to Shielder/Staff reproduction number
    beta_sc = scenario["CH.Rt.High"],   # Staff to Care home reproduction number (assume equal to beta_cs)
    
    
    # Remaining Shielder/Staff transmission rates 
    
    beta_s = (scenario["R.Rt.High"]+scenario["CH.Rt.High"])/2,   # internal Staff reproduction number
    beta_ss = (scenario["R.Rt.High"]+scenario["CH.Rt.High"])/2,   # between Staff reproduction number (could be higher than beta_rr due to mixing in workplace?)
    
    # Remaining Rest of Population transmission rates 
    beta_rr = scenario["R.Rt.High"] # rest of population to rest of population reproduction number    #4.56 is latency = 5.8 instead of 8
  )
  
  
  baseRLow_pars <- list(
    
    beta_c  = scenario["CH.Rt.Low"], # internal Care home reproduction number
    beta_cc = 0,  # between Care home reproduction number
    
    beta_cs = scenario["CH.Rt.Low"],# Care home to Shielder/Staff treproduction number
    beta_sc = scenario["CH.Rt.Low"],# Staff to Care home reproduction number (assume equal to beta_cs)
    
    # Remaining Shielder/Staff reproduction number
    
    beta_s = (0.6+scenario["CH.Rt.Low"])/2, # internal Staff reproduction number
    beta_ss = (0.6+scenario["CH.Rt.Low"])/2,# between Staff reproduction number (could be higher than beta_rr due to mixing in workplace?)
    
    # Remaining Rest of Population reproduction numbers
    beta_rr = 0.6 # rest of population to rest of population reproduction number    #0.7 if latency = 5.8 instead of 8
  )
  
  
  
  baseEnd_pars <- list(
    
    c = scenario["CH.Rt.End"],   # internal Care home logi function end time
    cc = scenario["CH.Rt.End"],  # between Care home logi function end time
    cs = scenario["CH.Rt.End"],  # Care home to Shielder/Staff logi function end time
    sc = scenario["CH.Rt.End"],  # Staff to Care home logi function end time
    
    # Remaining Shielder/Staff logi function end times
    
    s = scenario["CH.Rt.End"],   # internal Staff logi function end time
    ss = scenario["CH.Rt.End"],  # between Staff logi function end time
                                 # # Note - Staff to rest of population logi function end time = rr
    rr = scenario["R.Rt.End"]    # rest of population to rest of population logi function end time
  )
  
  baseRate_pars <- list(
    
    c = scenario["CH.Rt.Rate"],  # internal Care home logi function rate value
    cc = scenario["CH.Rt.Rate"], # between Care home logi function rate value
    cs = scenario["CH.Rt.Rate"], # Care home to Shielder/Staff logi function rate value
    sc = scenario["CH.Rt.Rate"], # Staff to Care home logi function rate value
    
    # Remaining Shielder/Staff logi function rate value
    
    s = scenario["CH.Rt.Rate"],  # internal Staff logi function rate value
    ss = scenario["CH.Rt.Rate"], # between Staff logi function rate value
    rr = scenario["R.Rt.Rate"]  # rest of population to rest of population logi function rate value
  )
  
  Infect_init <- list(     # initial infected parameters
    
    # The initial total infected (reported + unreported, or symptomatic + asymptomatic)
    # in each subpopulation (e.g. R_total_infected) is split evenly between the 
    # subpopulations in that population that have an initial outbreak (e.g. R_subs_inf).
    
    C_subs_inf = C_initial_dist(seg_pars, scenario["number.CHs.with.outbreak"]),  # C subpopulations that all initial C cases (C_total_infected) is split evenly between. Length must be less than or equal to seg_pars$C_pops. If no subpopulations have outbreak set as NULL.
    S_subs_inf = c(1),  # S subpopulations that all initial S cases (S_total_infected) is split evenly between. Length must be less than or equal to seg_pars$S_pops. If no subpopulations have outbreak set as NULL.
    R_subs_inf = c(1),                   # R subpopulations that all initial R cases (R_total_infected) is split evenly between. Length must be less than or equal to seg_pars$R_pops. If no subpopulations have outbreak set as NULL.
    
    C_total_infected = scenario["number.CHs.with.outbreak"]/(1-asymptomatic_proportions$C_asymp),    # i.e. assuming 1 symptomatic case in "number.CHs.with.outbreak" homes         # total initial infected across all care home sub-populations
    S_total_infected = 0,                           # total initial infected across all staff sub-populations
    R_total_infected = scenario["initial.R.Inf"]   # total initial infected across all rest sub-populations
    
    # Note: this requires (initial total infected + initital total exposed)/(number subpopulations with initial outbreak) = total infected or exposed in subpopulation initially < = capacity of that subpopulation
    #       for every C, S and R subpopulation.
    
  )
  
  parms_passed$Travel_pars <- list(
    
    # Parameters used to create the travel matrix, T. 
    # This is the matrix whose [i,j] element is the
    # the proportion of subpopulation i who travel to j
    
    # To create this matrix these get passed into create_TravelMatrix
    
    # note that these proportions are "averaged out over a whole day"
    
    delta = scenario["delta.vals"],     # Proportion of staff who are at CH's instead of mixing with Rest. Controls how many staff are at each CH on average.
    
    # epsilon and gamma are time dependent (we model their trajectories using the logi function)
    
    epsilon_pars =  list(start = -82,        # epsilon is proportion of a CH's staff who work at other homes
                         end = scenario["R.Rt.End"],
                         rate = scenario["R.Rt.Rate"], 
                         low = scenario["epsilon.vals"],      # epsilon is constant if high = low
                         high = scenario["epsilon.vals"]),
    
    gamma_pars =  list(start = -82,        # gamma is the proportion of Rest that visit each CH. Total proportion who visit is seg_pars$C_pops*gamma. General form of gamma = x(sub_pop_sizes$C_internal/sub_pop_sizes$R_internal)(y), where x is the number of visitors per day per resident, and y is the proportion of a day a visitor spends at a care home
                       end = 10,
                       rate = 3,
                       low = 0,
                       high = scenario["gamma.vals"])
    
    # community.size = 2                            # Total number of homes some proportion of a CH's staff work at (including "their" home)
  )
    

  # generate initial SEIRD values per sub-population as a vector
  SEIRD_vectors <- create_SEIRDVector(seg_pars, sub_pop_sizes, Infect_init, asymptomatic_proportions)
  
  
  # FIRST WAVE matrices #
  
  # Create matrix of baseRLow values
  parms_passed$baseRLow_matrix <- create_RMatrix(baseRLow_pars,seg_pars,between_pars)
  
  # create matrix of baseRHigh values
  parms_passed$baseRHigh_matrix <- create_RMatrix(baseRHigh_pars, seg_pars,between_pars)
  
  # create matrix of baseEnd values
  parms_passed$baseEnd_matrix <- create_WaveMatrix(baseEnd_pars, seg_pars)
  
  #
  
  #
  
  #
  
  # Now that parameters have been changed, generate the model ouput 
  
  # create simulation data
  sims_multi_logi <- ode(y = SEIRD_vectors, times = simTime, func = seird_multi_logi, parms = parms_passed)
  
  # array holds SEIRD values, e.g., S_c = Carehome_values[,,1], E_c = Carehome_values[,,2], etc.
  Carehome_values <- careHome_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
  
  # array holds SEIRD values, e.g., S_s = multiple_scenario_output[[i]]$Shielder_values[,,1], E_s = multiple_scenario_output[[i]]$Shielder_values[,,2], etc.
  Shielder_values <- Shielder_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
  
  # array holds SEIRD values, e.g., S_R = multiple_scenario_output[[i]]$Shielder_values[,,1], E_R = multiple_scenario_output[[i]]$Shielder_values[,,2], etc.
  Rest_values <- Rest_Aggregation(time = simTime, data = sims_multi_logi, seg_parms = seg_pars)
  
  #
  
  #
  
  #
  
  # And calculate the least squares error of model solution versus data 
  
  # Weekly Lothian CSR cases  
  LSE_CSR_cases_data <- sum( ( diff(c(0, (cumsum(rowSums(Shielder_values[,,3])+Rest_values[,,3]+rowSums(Carehome_values[,,3]))/parms_passed$Tau)[seq(4, length(Date.sim) , by  = 7 )]))  - weekly_csr_cases)^2 ) 
  
  
  # Weekly Lothian CSR deaths
  LSE_CSR_death_data <- sum((diff(c(0,(rowSums(Shielder_values[,,6])+Rest_values[,,6]+rowSums(Carehome_values[,,6]))[seq(4, length(Date.sim) , by  = 7 )])) - 
                               Weekly_Deaths_Lothian$WeeklyDeaths)^2)
  
  # Weekly CH cases
  LSE_ch_case_data <- sum((diff(c( cumsum(rowSums(Carehome_values[,,3])/parms_passed$Tau)[11],
                                   cumsum(rowSums(Carehome_values[,,3])/parms_passed$Tau)[Date.sim %in% weekly_ch_case_dates])) - weekly_ch_cases )^2)
  
  # Weekly CH deaths
  LSE_ch_death_data <- sum( ( diff(c(0,(rowSums(Carehome_values[,,6])[seq(4, length(Date.sim) , by  = 7 )])))-(Lothian_CH_death_data$`COVID-19 deaths 2020`) )^2 )
  
  
  # Sum of all least squares errors
  
  LSE_aggregate <- LSE_CSR_cases_data + LSE_CSR_death_data + LSE_ch_case_data + LSE_ch_death_data
  
  
  
  print(1)
  
  return(list("LSE_CSR_cases_data" = LSE_CSR_cases_data
              ,"LSE_CSR_death_data" = LSE_CSR_death_data
              ,"LSE_ch_case_data" = LSE_ch_case_data
              ,"LSE_ch_death_data" = LSE_ch_death_data
              ,"LSE_aggregate" = LSE_aggregate
              ,"Carehome_values" = Carehome_values
              ,"Shielder_values" = Shielder_values
              ,"Rest_values" = Rest_values)
         )
  
}



# 4) Calculations -----------------------------------

# library(parallel)


# convert scenario_matrix to a list of rows
# this is so we can use lappply to apply the function model_output to each row of scenario_matrix

scenario_list <- as.list(as.data.frame(t(scenario_matrix)))

indices <- c(1:nrow(scenario_matrix))   # indices for rows of scenario_matrix to 

scenario_list <- lapply(indices
                           ,function(x){names(scenario_list[[x]]) <- colnames(scenario_matrix)
                            return(scenario_list[[x]])}
                        )



# now calculate model output and least squares for every scenario

# Calculate the number of cores
no_cores <- 40

# Initiate cluster
cl <- makeCluster(no_cores, type = "FORK", outfile = "progress.txt")   # outfile allows us to track progress of the simulations

# WARNING: THIS TAKES A VERY LONG TIME. ~ 16+ hours, dependent on hardware
multiple_scenario_output <- parLapply(cl, scenario_list,
                                   function(scenario_mat){model_output(scenario_mat
                                                                       ,simTime
                                                                       ,seg_pars
                                                                       ,sub_pop_sizes
                                                                       ,between_pars
                                                                       ,asymptomatic_proportions
                                                                       ,parms_passed
                                                                       ,Date.sim
                                                                       ,Lothian
                                                                       ,Weekly_Deaths_Lothian
                                                                       ,daily.carehome.case.count
                                                                       ,death.count.weeks
                                                                       ,C.H.weekly.death.count)}

)


stopCluster(cl)

  
# 5) Save all data --------------------------

# (Store data then save)

# Sum of squared errors/Least squares errors for all scenarios
Least_Squares_Errors <- data.frame(LSE_CSR_cases_data = unlist(lapply(multiple_scenario_output, `[[`, 1)),
                                    LSE_CSR_death_data = unlist(lapply(multiple_scenario_output, `[[`, 2)),
                                    LSE_ch_case_data = unlist(lapply(multiple_scenario_output, `[[`, 3)),
                                    LSE_ch_death_data = unlist(lapply(multiple_scenario_output, `[[`, 4)),
                                    all_aggregated_LSE = unlist(lapply(multiple_scenario_output, `[[`, 5)) 
 )
save(Least_Squares_Errors, file = "Least_Squares_Errors.RData")


# Now, save outputs for the top ten scenarios

# find indices of the top 10
toptenLSE <- head(sort(Least_Squares_Errors$all_aggregated_LSE,decreasing = F, index.return=TRUE)$ix,10)    # these are the 10 scenarios with the smallest least squares error

 top_ten_scenarios_outputs<-list(multiple_scenario_output[[toptenLSE[1]]],
                                multiple_scenario_output[[toptenLSE[2]]],
                                multiple_scenario_output[[toptenLSE[3]]],
                                multiple_scenario_output[[toptenLSE[4]]],
                                multiple_scenario_output[[toptenLSE[5]]],
                                multiple_scenario_output[[toptenLSE[6]]],
                                multiple_scenario_output[[toptenLSE[7]]],
                                multiple_scenario_output[[toptenLSE[8]]],
                                multiple_scenario_output[[toptenLSE[9]]],
                                multiple_scenario_output[[toptenLSE[10]]]
 )
 
save(top_ten_scenarios_outputs, file = "top_ten_scenarios_outputs.RData")
 
 


# 6) Save extra data inc. more on top scenario ----------------------------


# first load in the data generated by steps 1)-6)

load("scenario_matrix.RData")
load("top_ten_scenarios_outputs.RData") 
load("Least_Squares_Errors.RData")

# indices of best scenarios
toptenLSE <- head(sort((Least_Squares_Errors$all_aggregated_LSE),decreasing = F, index.return=TRUE)$ix,10)

# Optimal parameters for the top ten scenarios
scenario_matrix[toptenLSE,]

# aggregated sum of squared errors for top ten scenarios
Least_Squares_Errors$all_aggregated_LSE[toptenLSE]

## Start with reproductive rates

## Reproductive rates

# Rest beta
r_logi <- logi(simTime, baseStart_pars$rr
               ,as.numeric(scenario_matrix[toptenLSE[1], "R.Rt.End" ])
               ,as.numeric(scenario_matrix[toptenLSE[1], "R.Rt.Rate" ])
               ,as.numeric(baseRLow_pars$beta_rr)
               ,as.numeric(scenario_matrix[toptenLSE[1], "R.Rt.High" ])
)

# Care home beta

c_logi <- logi(simTime, baseStart_pars$c
               ,as.numeric(scenario_matrix[toptenLSE[1], "CH.Rt.End" ])
               ,as.numeric(scenario_matrix[toptenLSE[1], "CH.Rt.Rate" ])
               ,as.numeric(scenario_matrix[toptenLSE[1], "CH.Rt.Low" ])
               ,as.numeric(scenario_matrix[toptenLSE[1], "CH.Rt.High" ])
)

# Staff beta

s_logi <- logi(simTime, baseStart_pars$c
               ,as.numeric(scenario_matrix[toptenLSE[1], "CH.Rt.End" ])
               ,as.numeric(scenario_matrix[toptenLSE[1], "CH.Rt.Rate" ])
               ,(as.numeric(scenario_matrix[toptenLSE[1], "CH.Rt.Low" ]) + as.numeric(baseRLow_pars$beta_rr))/2
               ,(as.numeric(scenario_matrix[toptenLSE[1], "CH.Rt.High" ]) + as.numeric(scenario_matrix[toptenLSE[1], "R.Rt.High" ]))/2
)



Model_weekly_total_cases <- diff(c(0, (cumsum(rowSums(top_ten_scenarios_outputs[[1]]$Shielder_values[,,3])+top_ten_scenarios_outputs[[1]]$Rest_values[,,3]+rowSums(top_ten_scenarios_outputs[[1]]$Carehome_values[,,3]))/parms_passed$Tau)[Date.sim %in% weekly_csr_case_dates]))

Model_weekly_total_deaths <- diff(c(0,(rowSums(top_ten_scenarios_outputs[[1]]$Shielder_values[,,6])+top_ten_scenarios_outputs[[1]]$Rest_values[,,6]+rowSums(top_ten_scenarios_outputs[[1]]$Carehome_values[,,6]))[Date.sim %in% Weekly_Deaths_Lothian$Date]))

Model_weekly_CH_cases <- diff(c(0, cumsum(rowSums(top_ten_scenarios_outputs[[1]]$Carehome_values[,,3])/parms_passed$Tau)[Date.sim %in% weekly_csr_case_dates]))                 # if using all model points

Model_weekly_CH_deaths <- diff(c(0,(rowSums(top_ten_scenarios_outputs[[1]]$Carehome_values[,,6])[Date.sim %in% Lothian_CH_death_data$`Week commencing`])))


seeded_4home_E_best_fit <- list(Model_weekly_total_cases = Model_weekly_total_cases,
                                Model_weekly_total_deaths = Model_weekly_total_deaths,
                                Model_weekly_CH_cases = Model_weekly_CH_cases,
                                Model_weekly_CH_deaths = Model_weekly_CH_deaths,
                                # Carehome_values = top_ten_scenarios_outputs[[1]]$Carehome_values, 
                                # Shielder_values = top_ten_scenarios_outputs[[1]]$Shielder_values,
                                # Rest_values = top_ten_scenarios_outputs[[1]]$Rest_values,
                                c_logi = c_logi,
                                s_logi = s_logi,
                                r_logi = r_logi,
                                LS = Least_Squares_Errors$all_aggregated_LSE[toptenLSE[1]],
                                Optimal_epsilon = as.numeric(scenario_matrix[toptenLSE[1], "epsilon.vals" ]),
                                Optimal_gamma = as.numeric(scenario_matrix[toptenLSE[1], "gamma.vals" ]),
                                Optimal_delta = as.numeric(scenario_matrix[toptenLSE[1], "delta.vals" ]),
                                All_params = scenario_matrix[toptenLSE[1],],
                                all_LS_sorted = sort(Least_Squares_Errors$all_aggregated_LSE,decreasing = F, index.return=TRUE)$x,    # from lowest to highest least squares
                                all_scenarios_sorted = scenario_matrix[sort(Least_Squares_Errors$all_aggregated_LSE,decreasing = F, index.return=TRUE)$ix,])      # scenarios sorted by those with lowest to highest least squares

save(seeded_4home_E_best_fit, file = "seeded_4home_E_best_fit.RData")



